import { useEffect, useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import { Button, FieldGroup, InlineMessage, TextAreaField, TextField } from './design-system/components';

type User = {
  user_id: string;
  name: string;
  age: number;
  phone?: string;
  registered_at?: string;
  last_activity?: string;
  conversationCount?: number;
  isBanned?: boolean;
};

type UsersPayload = {
  items: User[];
  total: number;
  page: number;
  pageSize: number;
};

type ChatImage = {
  url: string;
  alt?: string;
};

type ProfileMessage = {
  role: 'user' | 'assistant';
  content: string;
  type?: string;
  timestamp?: string;
  status?: string;
  taskId?: string;
  imageTaskId?: string;
  imageUrl?: string;
  resultUrl?: string;
  images?: ChatImage[];
};

type UserProfile = User & {
  conversations: Array<{
    conversation_id: string;
    title: string;
    message_count: number;
    last_message_at?: string;
    messages: ProfileMessage[];
  }>;
};

type DashboardStats = {
  kpis: {
    totalUsers: number;
    activeUsersToday: number;
    apiCallsToday: number;
    errorCountToday: number;
  };
  userGrowth: Array<{ date: string; users: number }>;
  apiUsage: Array<{ date: string; calls: number }>;
  errorDistribution: Array<{ error_type: string; count: number }>;
  recentActivities: Array<{
    timestamp: string;
    adminUsername: string;
    action: string;
    target: string | null;
    details?: Record<string, unknown>;
  }>;
};

type SubscriptionPlan = {
  id: string;
  name: string;
  icon: string;
  tagline?: string;
  monthlyPrice: number;
  dailyPrice: number;
  dailyMessageLimit: number | null;
  dailyImageLimit: number | null;
  hourlyImageLimit: number | null;
  features: string[];
  isActive: boolean;
  sortOrder: number;
};

type UserSubscription = {
  userId: string;
  planId: string;
  status: string;
  assignedAt?: string;
  expiresAt?: string | null;
  note?: string;
  plan?: SubscriptionPlan | null;
  user?: User | null;
};

type SubscriptionsPayload = {
  plans: SubscriptionPlan[];
  userSubscriptions: UserSubscription[];
  users: User[];
  updatedAt?: string;
};

type SiteSettingsPayload = {
  settings: Record<string, any>;
  definitions?: Record<string, { label: string; type: string; category: string; allowedValues?: string[] }>;
};

type AiRuntimeStatus = {
  chat: {
    provider: string;
    model?: string | null;
    baseUrlHost?: string;
    apiKeySource: string;
    apiKeySet: boolean;
    apiKeyFingerprint?: string;
  };
  image: {
    enabled?: boolean;
    provider: string;
    modelSource?: string;
    modelAdminValue: string;
    modelRuntimeValue: string;
    modelProviderName?: string;
    operation?: string;
    baseUrlHost?: string;
    apiKeySource: string;
    apiKeySet: boolean;
    apiKeyFingerprint?: string;
    resolution: string;
    aspectRatio: string;
    outputFormat: string;
    safetyFilterLevel: string;
    pollIntervalMs?: number;
    pollTimeoutMs?: number;
    maxDownloadMb?: number;
    editEnabled?: boolean;
    promptEnhancerEnabled?: boolean;
    lastValidationStatus?: string;
    storageDir?: string;
    storageWritable?: boolean;
    publicServeRoute?: string;
  };
  imagePromptRefiner?: {
    enabled: boolean;
    provider: string;
    model: string;
    apiKeySource: string;
    apiKeySet: boolean;
    apiKeyFingerprint?: string;
    temperature: number;
    maxTokens: number;
    timeoutMs: number;
    fallbackEnabled: boolean;
    cacheEnabled: boolean;
    cacheTtlMinutes: number;
    lastValidationStatus?: string;
  };
  intentRouter?: {
    enabled: boolean;
    provider: string;
    model: string;
    fallbackModel: string;
    experimentalModel: string;
    apiKeySource: string;
    apiKeySet: boolean;
    apiKeyFingerprint?: string;
    allowModelFallback: boolean;
    allowChatKeyFallback: boolean;
    fallbackToHeuristic: boolean;
    confidenceThreshold: number;
    timeoutMs: number;
    maxOutputTokens: number;
    temperature: number;
    storeMetadata: boolean;
    health: {
      enabled: boolean;
      failureThreshold: number;
      cooldownMinutes: number;
      models: Record<string, {
        status: string;
        failures?: number;
        cooldownUntil?: string | null;
        lastError?: {
          statusCode?: number | null;
          errorType?: string;
          safeMessage?: string;
          upstreamCode?: string;
        } | null;
      }>;
    };
    lastValidationStatus?: string;
  };
  vision?: {
    enabled: boolean;
    provider: string;
    mode: string;
    defaultModel: string;
    fastModel: string;
    experimentalModel?: string;
    qualityModel: string;
    proModel: string;
    allowProModel: boolean;
    apiKeySource: string;
    apiKeySet: boolean;
    apiKeyFingerprint?: string;
    transport: string;
    timeoutMs: number;
    fallbackTimeoutMs: number;
    maxImageMb: number;
    mediaResolution: string;
    temperature: number;
    maxOutputTokens: number;
    selectedModelForSimpleImage?: string;
    selectedModelForOcrOrDesign?: string;
    modelHealth?: Record<string, {
      status: string;
      failures?: number;
      cooldownUntil?: string | null;
      lastError?: {
        statusCode?: number | null;
        errorType?: string;
        safeMessage?: string;
        upstreamCode?: string;
      } | null;
    }>;
    lastValidationStatus?: string;
  };
};

type ImageModelPreset = {
  id: string;
  label: string;
  adminValue: string;
  provider: string;
  runtimeProviderName: string;
  runtimeModel: string;
  operation: string;
  supportsImageEdit?: boolean;
  defaultResolution?: string;
};

type SupervisedOtpConfig = {
  enabled: boolean;
  hasCode: boolean;
  expires_at?: string | null;
  max_uses?: number | null;
  used_count: number;
  updated_at?: string | null;
};

const PIE_COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4', '#3b82f6', '#a855f7'];
type AdminTab = 'dashboard' | 'users' | 'subscriptions' | 'limits' | 'errors' | 'siteSettings' | 'supervisedOtp' | 'config' | 'audit';
type ReportUserScope = 'all' | 'selected';
type ReportFormat = 'csv' | 'txt';
type ReportSection =
  | 'users'
  | 'errors'
  | 'conversation_summary'
  | 'messages'
  | 'plans_usage'
  | 'guest_usage'
  | 'ai_performance'
  | 'guest_conversations'
  | 'supervised_otp_usage';
type ReportRangePreset = 'today' | '7d' | '30d' | 'custom';
const USERS_PAGE_SIZE = 10;
const parseNullableNumberInput = (value: string): number | null => (
  value.trim() === '' ? null : Number(value)
);
const normalizeLimitValue = (value: number | null | undefined) => (
  value === null || value === undefined ? null : Math.max(0, Number(value) || 0)
);
const formatLimitLabel = (value: number | null | undefined, unit: string) => {
  if (value === null || value === undefined) return 'نامحدود';
  if (Number(value) === 0) return 'غیرفعال';
  return `${new Intl.NumberFormat('fa-IR').format(Number(value))} ${unit}`;
};
const getLimitTone = (messageLimit: number | null | undefined, dailyImageLimit: number | null | undefined, hourlyImageLimit: number | null | undefined) => {
  if (messageLimit === 0 || dailyImageLimit === 0 || hourlyImageLimit === 0) return 'blocked';
  if (messageLimit === null && dailyImageLimit === null && hourlyImageLimit === null) return 'unlimited';
  return 'limited';
};
const LIMIT_PRESETS = [
  { id: 'starter', label: 'شروع امن', message: 10, dailyImage: 2, hourlyImage: 1 },
  { id: 'balanced', label: 'متعادل', message: 50, dailyImage: 10, hourlyImage: 4 },
  { id: 'unlimited', label: 'نامحدود', message: null, dailyImage: null, hourlyImage: null },
  { id: 'images-off', label: 'تصویر خاموش', message: null, dailyImage: 0, hourlyImage: 0 }
] as const;
const TAB_LABELS: Record<AdminTab, string> = {
  dashboard: 'داشبورد',
  users: 'کاربران',
  subscriptions: 'اشتراک‌ها',
  limits: 'لیمیت‌ها',
  errors: 'خطاها',
  siteSettings: 'تنظیمات سایت',
  supervisedOtp: 'Supervised OTP',
  config: 'سیستم',
  audit: 'Audit'
};

const TAB_ICONS: Record<keyof typeof TAB_LABELS, string> = {
  dashboard: '▦',
  users: '◎',
  subscriptions: '◈',
  limits: '⏱',
  errors: '!',
  siteSettings: '⚙',
  supervisedOtp: 'OTP',
  config: '⚙',
  audit: '⌁'
};

const REPORT_SECTION_OPTIONS: Array<{ key: ReportSection; label: string }> = [
  { key: 'users', label: 'users' },
  { key: 'errors', label: 'errors' },
  { key: 'conversation_summary', label: 'conversation summary' },
  { key: 'messages', label: 'messages' },
  { key: 'plans_usage', label: 'plans usage' },
  { key: 'guest_usage', label: 'guest usage' },
  { key: 'ai_performance', label: 'AI performance' },
  { key: 'guest_conversations', label: 'چت‌های مهمان' },
  { key: 'supervised_otp_usage', label: 'Supervised OTP' }
];
const FALLBACK_IMAGE_MODEL_PRESETS: ImageModelPreset[] = [
  {
    id: 'nano-banana-pro',
    label: 'Nano Banana Pro',
    adminValue: 'gemini-3-pro-image',
    provider: 'metis',
    runtimeProviderName: 'google',
    runtimeModel: 'nano-banana-pro',
    operation: 'Imagine',
    supportsImageEdit: true,
    defaultResolution: '1K'
  },
  {
    id: 'nano-banana',
    label: 'Nano Banana',
    adminValue: 'gemini-2.5-flash-image',
    provider: 'metis',
    runtimeProviderName: 'google',
    runtimeModel: 'nano-banana',
    operation: 'Imagine',
    supportsImageEdit: true,
    defaultResolution: '1K'
  },
  {
    id: 'flux-schnell',
    label: 'Flux Schnell',
    adminValue: 'flux-schnell',
    provider: 'metis',
    runtimeProviderName: 'black-forest-labs',
    runtimeModel: 'flux-schnell',
    operation: 'Imagine',
    supportsImageEdit: false,
    defaultResolution: '1K'
  },
  {
    id: 'custom',
    label: 'Custom',
    adminValue: 'custom',
    provider: 'metis',
    runtimeProviderName: '',
    runtimeModel: '',
    operation: 'Imagine',
    supportsImageEdit: false,
    defaultResolution: '1K'
  }
];
const IMAGE_PROVIDER_OPTIONS = ['metis', 'gemini', 'xai'];
const IMAGE_RESOLUTION_OPTIONS = ['1K', '2K'];
const IMAGE_ASPECT_RATIO_OPTIONS = ['1:1', '2:3', '3:2', '3:4', '4:3', '4:5', '5:4', '9:16', '16:9', '21:9'];
const IMAGE_OUTPUT_FORMAT_OPTIONS = ['jpg', 'png'];
const IMAGE_SAFETY_FILTER_OPTIONS = [
  'block_only_high',
  'block_medium_and_above',
  'block_low_and_above',
  'block_none'
];
const IMAGE_PROMPT_REFINER_DEFAULT_STYLE = 'clean, colorful, child-friendly digital illustration, soft lighting, high quality';
const IMAGE_PROMPT_REFINER_DEFAULT_NEGATIVE = 'no watermark, no distorted text, no extra fingers, no blurry face, no unrelated objects';
const IMAGE_PROMPT_REFINER_DEFAULT_SYSTEM_PROMPT = 'You are an image prompt refinement engine for a Persian child-friendly AI product. Return only valid JSON matching the requested schema. Preserve the main subject, keep Persian text inside the image unchanged, and enforce child-safe rules.';
const INTENT_ROUTER_MODEL_OPTIONS = ['gemini-2.5-flash-lite-preview', 'gemini-2.5-flash'];
const INTENT_ROUTER_DEFAULT_SYSTEM_PROMPT = 'You are an internal intent router. Classify the user request into chat, image_generation, image_edit, or image_understanding. Return only valid JSON.';
const VISION_TRANSPORT_OPTIONS = ['auto', 'inline', 'metis_storage'];
const VISION_MODE_OPTIONS = ['economy', 'balanced', 'accurate', 'pro'];
const VISION_MEDIA_RESOLUTION_OPTIONS = ['auto', 'normal', 'high'];
const VISION_DEFAULT_SYSTEM_PROMPT = 'You are a professional image understanding engine for a Persian child-friendly AI product.\n\nAnalyze the provided image accurately. Do not guess beyond visible evidence. If something is uncertain, say it is uncertain.\n\nReturn the answer in Persian unless the user asks otherwise.\n\nIf the user asks to read text, prioritize OCR-like accuracy. If the image is blurry, rotated, cropped, too small, or unreadable, say so clearly. Do not hallucinate. Do not identify real people by name.';
const VISION_DEFAULT_OCR_PROMPT = 'Read all visible text in the image exactly as written. Preserve Persian text exactly. If text is unclear, mark it as unclear instead of guessing.';
const VISION_DEFAULT_DESIGN_PROMPT = 'Analyze this design visually. Comment on layout, colors, readability, hierarchy, spacing, and what could be improved. Be concise and practical.';
const normalizeVisionModeForPanel = (value: unknown) => {
  const mode = String(value || 'balanced');
  if (mode === 'quality') return 'accurate';
  if (mode === 'fast') return 'economy';
  return VISION_MODE_OPTIONS.includes(mode) ? mode : 'balanced';
};

const formatDateInput = (date: Date) => {
  const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60 * 1000);
  return localDate.toISOString().slice(0, 10);
};

const formatDateTimeLocalInput = (value?: string | null) => {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60 * 1000);
  return localDate.toISOString().slice(0, 16);
};

// ─── Shared error helpers for admin routes ───
const handleAdminResponse = async (response: Response, fallback: string): Promise<{ ok: boolean; data?: any }> => {
  if (response.status === 401) {
    window.location.href = '/admin/login';
    return { ok: false };
  }
  if (!response.ok) {
    let message = fallback;
    try {
      const payload = await response.json();
      if (payload?.error || payload?.message) message = payload.error || payload.message;
    } catch { /* ignore JSON parse error */ }
    throw new Error(message);
  }
  const data = await response.json();
  return { ok: true, data };
};

const toAdminProfileImageUrl = (url: string, userId: string) => {
  const raw = typeof url === 'string' ? url.trim() : '';
  if (!raw) return '';
  const userPath = encodeURIComponent(userId);

  try {
    const parsed = new URL(raw, window.location.origin);
    const generatedMatch = parsed.pathname.match(/^\/api\/images\/(?:serve|result)\/([^/?#]+)/);
    if (generatedMatch) {
      return `/api/admin/users/${userPath}/images/${encodeURIComponent(decodeURIComponent(generatedMatch[1]))}`;
    }
    if (parsed.origin === window.location.origin) {
      return `${parsed.pathname}${parsed.search}${parsed.hash}`;
    }
    return raw;
  } catch {
    const generatedMatch = raw.match(/^\/api\/images\/(?:serve|result)\/([^/?#]+)/);
    if (generatedMatch) {
      return `/api/admin/users/${userPath}/images/${encodeURIComponent(decodeURIComponent(generatedMatch[1]))}`;
    }
    return raw;
  }
};

const getProfileMessageImages = (message: ProfileMessage, userId: string): ChatImage[] => {
  const candidates: ChatImage[] = [];
  if (Array.isArray(message.images)) {
    message.images.forEach((image) => {
      if (image?.url) candidates.push(image);
    });
  }
  if (message.imageUrl) candidates.push({ url: message.imageUrl, alt: message.content || 'تصویر گفتگو' });
  if (message.resultUrl) candidates.push({ url: message.resultUrl, alt: message.content || 'تصویر گفتگو' });

  const taskId = message.taskId || message.imageTaskId;
  if (taskId && (message.type === 'image_result' || message.status === 'COMPLETED')) {
    candidates.push({ url: `/api/admin/users/${encodeURIComponent(userId)}/images/${encodeURIComponent(taskId)}`, alt: message.content || 'تصویر ساخته‌شده' });
  }

  const seen = new Set<string>();
  return candidates
    .map((image) => ({
      url: toAdminProfileImageUrl(image.url, userId),
      alt: image.alt || message.content || 'تصویر گفتگو'
    }))
    .filter((image) => {
      if (!image.url || seen.has(image.url)) return false;
      seen.add(image.url);
      return true;
    });
};

function AdminPanel() {
  const [tab, setTab] = useState<AdminTab>('dashboard');
  const [users, setUsers] = useState<User[]>([]);
  const [usersTotal, setUsersTotal] = useState(0);
  const [usersPage, setUsersPage] = useState(1);
  const [query, setQuery] = useState('');
  const [banFilter, setBanFilter] = useState('all');
  const [selectedReportUserIds, setSelectedReportUserIds] = useState<string[]>([]);
  const [reportUserScope, setReportUserScope] = useState<ReportUserScope>('all');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [errors, setErrors] = useState<any[]>([]);
  const [config, setConfig] = useState<any>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [reportFormat, setReportFormat] = useState<ReportFormat>('csv');
  const [reportRangePreset, setReportRangePreset] = useState<ReportRangePreset>('7d');
  const [reportCustomFromDate, setReportCustomFromDate] = useState('');
  const [reportCustomToDate, setReportCustomToDate] = useState('');
  const [reportGuestOnly, setReportGuestOnly] = useState(false);
  const [reportMinGuestMessages, setReportMinGuestMessages] = useState('0');
  const [reportGuestErrorsOnly, setReportGuestErrorsOnly] = useState(false);
  const [reportAmbiguousOnly, setReportAmbiguousOnly] = useState(false);
  const [reportOptions, setReportOptions] = useState<Record<ReportSection, boolean>>({
    users: true,
    errors: false,
    conversation_summary: false,
    messages: false,
    plans_usage: false,
    guest_usage: false,
    ai_performance: true,
    guest_conversations: false,
    supervised_otp_usage: false
  });
  const [dashboard, setDashboard] = useState<DashboardStats | null>(null);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [dashboardError, setDashboardError] = useState('');
  const [configSaving, setConfigSaving] = useState(false);
  const [configMessage, setConfigMessage] = useState('');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [systemPromptLoading, setSystemPromptLoading] = useState(false);
  const [systemPromptSaving, setSystemPromptSaving] = useState(false);
  const [systemPromptMessage, setSystemPromptMessage] = useState('');
  const [loadError, setLoadError] = useState('');
  const [actionError, setActionError] = useState('');
  const [subscriptions, setSubscriptions] = useState<SubscriptionsPayload | null>(null);
  const [subscriptionMessage, setSubscriptionMessage] = useState('');
  const [subscriptionSaving, setSubscriptionSaving] = useState(false);
  const [limitsMessage, setLimitsMessage] = useState('');
  const [limitsSaving, setLimitsSaving] = useState(false);
  const [assignForm, setAssignForm] = useState({ userId: '', planId: 'gold', expiresAt: '', note: '' });
  const [siteSettings, setSiteSettings] = useState<SiteSettingsPayload | null>(null);
  const [siteSettingsSaving, setSiteSettingsSaving] = useState(false);
  const [siteSettingsMessage, setSiteSettingsMessage] = useState('');
  const [aiRuntimeStatus, setAiRuntimeStatus] = useState<AiRuntimeStatus | null>(null);
  const [imageModelPresets, setImageModelPresets] = useState<ImageModelPreset[]>(FALLBACK_IMAGE_MODEL_PRESETS);
  const [imageTestPrompt, setImageTestPrompt] = useState('A single blue banana, clean white background');
  const [imageTestResult, setImageTestResult] = useState<any>(null);
  const [imageTestMessage, setImageTestMessage] = useState('');
  const [imageTestLoading, setImageTestLoading] = useState(false);
  const [visionTestPrompt, setVisionTestPrompt] = useState('این عکس رو دقیق توضیح بده');
  const [visionTestFile, setVisionTestFile] = useState<File | null>(null);
  const [visionTestResult, setVisionTestResult] = useState<any>(null);
  const [visionTestMessage, setVisionTestMessage] = useState('');
  const [visionTestLoading, setVisionTestLoading] = useState(false);
  const [intentRouterTestPrompt, setIntentRouterTestPrompt] = useState('گربه‌ی توی عکس رو قرمز کن');
  const [intentRouterTestResult, setIntentRouterTestResult] = useState<any>(null);
  const [intentRouterTestMessage, setIntentRouterTestMessage] = useState('');
  const [intentRouterTestLoading, setIntentRouterTestLoading] = useState(false);
  const [supervisedOtp, setSupervisedOtp] = useState<SupervisedOtpConfig | null>(null);
  const [supervisedOtpForm, setSupervisedOtpForm] = useState({
    enabled: false,
    code: '',
    expires_at: '',
    max_uses: ''
  });
  const [supervisedOtpSaving, setSupervisedOtpSaving] = useState(false);
  const [supervisedOtpMessage, setSupervisedOtpMessage] = useState('');

  const loadUsers = async (page = usersPage) => {
    setLoadError('');
    const params = new URLSearchParams();
    if (query.trim()) params.set('q', query.trim());
    if (banFilter !== 'all') params.set('isBanned', banFilter);
    params.set('page', String(page));
    params.set('pageSize', String(USERS_PAGE_SIZE));
    try {
      const response = await fetch(`/api/admin/users?${params.toString()}`, { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری کاربران ناموفق بود.');
      if (!result.ok) return;
      const payload = (result.data || {}) as UsersPayload;
      const nextPage = Number(payload.page || page);
      setUsers(payload.items || []);
      setUsersTotal(Number(payload.total || 0));
      setUsersPage(nextPage);
    } catch {
      setLoadError('اتصال به سرور برقرار نشد. لطفاً دوباره تلاش کنید.');
    }
  };

  const loadDashboard = async () => {
    setDashboardLoading(true);
    setDashboardError('');

    try {
      const response = await fetch('/api/admin/dashboard/stats', { credentials: 'include' });
      if (response.status === 401) {
        window.location.href = '/admin/login';
        return;
      }
      if (!response.ok) {
        throw new Error('بارگذاری داده های داشبورد ناموفق بود.');
      }
      const payload = (await response.json()) as DashboardStats;
      setDashboard(payload);
    } catch (_error) {
      setDashboardError('دریافت اطلاعات داشبورد با خطا مواجه شد. لطفا دوباره تلاش کنید.');
    } finally {
      setDashboardLoading(false);
    }
  };

  const loadErrors = async () => {
    try {
      const response = await fetch('/api/admin/errors', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری خطاها ناموفق بود.');
      if (result.ok) setErrors(result.data.items || []);
    } catch {
      console.error('[admin] loadErrors failed');
    }
  };

  const loadConfig = async () => {
    try {
      const response = await fetch('/api/admin/config', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری تنظیمات ناموفق بود.');
      if (result.ok) setConfig(result.data);
    } catch {
      console.error('[admin] loadConfig failed');
    }
  };

  const loadSystemPrompt = async () => {
    setSystemPromptLoading(true);
    setSystemPromptMessage('');
    try {
      const response = await fetch('/api/admin/config/system-prompt', { credentials: 'include' });
      if (response.status === 401) {
        window.location.href = '/admin/login';
        return;
      }
      if (!response.ok) {
        throw new Error('load_failed');
      }
      const payload = await response.json();
      setSystemPrompt(typeof payload.systemPrompt === 'string' ? payload.systemPrompt : '');
    } catch (_error) {
      setSystemPromptMessage('خواندن سیستم پرامپت ناموفق بود.');
    } finally {
      setSystemPromptLoading(false);
    }
  };

  const loadLogs = async () => {
    try {
      const response = await fetch('/api/admin/audit-logs?page=1&pageSize=50', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری لاگ ها ناموفق بود.');
      if (result.ok) setLogs(result.data.items || []);
    } catch {
      console.error('[admin] loadLogs failed');
    }
  };

  const loadSubscriptions = async () => {
    setSubscriptionMessage('');
    try {
      const response = await fetch('/api/admin/subscriptions', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری اشتراک‌ها ناموفق بود.');
      if (result.ok) {
        setSubscriptions(result.data);
        const firstUser = result.data.users?.[0]?.user_id || '';
        const firstPlan = result.data.plans?.find((plan: SubscriptionPlan) => plan.id !== 'free')?.id || result.data.plans?.[0]?.id || 'gold';
        setAssignForm((prev) => ({
          ...prev,
          userId: prev.userId || firstUser,
          planId: prev.planId || firstPlan
        }));
      }
    } catch {
      setSubscriptionMessage('اتصال به سرور برای دریافت اشتراک‌ها برقرار نشد.');
    }
  };

  const loadSiteSettings = async () => {
    setSiteSettingsMessage('');
    try {
      const response = await fetch('/api/admin/settings', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری تنظیمات سایت ناموفق بود.');
      if (result.ok) setSiteSettings(result.data);
    } catch (error) {
      setSiteSettingsMessage(error instanceof Error ? error.message : 'اتصال به سرور برای دریافت تنظیمات سایت برقرار نشد.');
    }
  };

  const loadAiRuntimeStatus = async () => {
    try {
      const response = await fetch('/api/admin/ai-runtime-status', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری وضعیت runtime هوش مصنوعی ناموفق بود.');
      if (result.ok) setAiRuntimeStatus(result.data as AiRuntimeStatus);
    } catch {
      setAiRuntimeStatus(null);
    }
  };

  const loadImageModelPresets = async () => {
    try {
      const response = await fetch('/api/admin/image-model-presets', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری presetهای مدل تصویر ناموفق بود.');
      if (result.ok && Array.isArray(result.data?.presets)) {
        setImageModelPresets(result.data.presets as ImageModelPreset[]);
      }
    } catch {
      setImageModelPresets(FALLBACK_IMAGE_MODEL_PRESETS);
    }
  };

  const loadSupervisedOtp = async () => {
    setSupervisedOtpMessage('');
    try {
      const response = await fetch('/api/admin/supervised-otp', { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری Supervised OTP ناموفق بود.');
      if (!result.ok) return;
      const config = result.data as SupervisedOtpConfig;
      setSupervisedOtp(config);
      setSupervisedOtpForm({
        enabled: Boolean(config.enabled),
        code: '',
        expires_at: formatDateTimeLocalInput(config.expires_at),
        max_uses: config.max_uses == null ? '' : String(config.max_uses)
      });
    } catch (error) {
      setSupervisedOtpMessage(error instanceof Error ? error.message : 'اتصال به سرور برای دریافت Supervised OTP برقرار نشد.');
    }
  };

  useEffect(() => {
    void loadDashboard();
    void loadUsers();
    void loadErrors();
    void loadConfig();
    void loadSystemPrompt();
    void loadLogs();
    void loadSubscriptions();
    void loadSiteSettings();
    void loadAiRuntimeStatus();
    void loadImageModelPresets();
    void loadSupervisedOtp();
  }, []);

  const visibleUsers = useMemo(() => users, [users]);
  const sortedPlans = useMemo(
    () => [...(subscriptions?.plans || [])].sort((a, b) => (a.sortOrder || 999) - (b.sortOrder || 999)),
    [subscriptions?.plans]
  );
  const activePlansCount = sortedPlans.filter((plan) => plan.isActive).length;
  const guestLimitTone = getLimitTone(
    siteSettings?.settings?.['guest.message_limit'],
    siteSettings?.settings?.['guest.image_limit_daily'],
    siteSettings?.settings?.['guest.image_limit_hourly']
  );
  const usersTotalPages = Math.max(1, Math.ceil(usersTotal / USERS_PAGE_SIZE));
  const selectedReportUsersOnPage = visibleUsers.filter((user) => selectedReportUserIds.includes(user.user_id));
  const isEveryVisibleUserSelected = visibleUsers.length > 0 && selectedReportUsersOnPage.length === visibleUsers.length;

  const handleApplyUserFilters = () => {
    void loadUsers(1);
  };

  const handleUsersPageChange = (nextPage: number) => {
    const safePage = Math.min(usersTotalPages, Math.max(1, nextPage));
    void loadUsers(safePage);
  };

  const toggleReportUser = (userId: string) => {
    setSelectedReportUserIds((prev) =>
      prev.includes(userId) ? prev.filter((item) => item !== userId) : [...prev, userId]
    );
    setReportUserScope('selected');
  };

  const toggleVisibleReportUsers = () => {
    const visibleIds = visibleUsers.map((user) => user.user_id);
    if (visibleIds.length === 0) return;
    setSelectedReportUserIds((prev) => {
      const withoutVisible = prev.filter((item) => !visibleIds.includes(item));
      return isEveryVisibleUserSelected ? withoutVisible : [...withoutVisible, ...visibleIds];
    });
    setReportUserScope('selected');
  };

  const toggleReportSection = (section: ReportSection, checked: boolean) => {
    setReportOptions((prev) => ({ ...prev, [section]: checked }));
  };

  const getReportDateRange = () => {
    if (reportRangePreset === 'custom') {
      return {
        fromDate: reportCustomFromDate.trim(),
        toDate: reportCustomToDate.trim()
      };
    }

    const today = new Date();
    const start = new Date(today);
    if (reportRangePreset === '7d') start.setDate(today.getDate() - 6);
    if (reportRangePreset === '30d') start.setDate(today.getDate() - 29);

    return {
      fromDate: formatDateInput(start),
      toDate: formatDateInput(today)
    };
  };

  const toggleBan = async (user: User) => {
    setActionError('');
    try {
      const response = await fetch(`/api/admin/users/${user.user_id}/ban`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ isBanned: !user.isBanned })
      });
      await handleAdminResponse(response, 'تغییر وضعیت کاربر ناموفق بود.');
      await loadUsers(usersPage);
    } catch {
      setActionError('عملیات با خطا مواجه شد. لطفاً دوباره تلاش کنید.');
    }
  };

  const deleteUser = async (user: User) => {
    if (!window.confirm('حذف کاربر و گفتگوها انجام شود؟')) return;
    setActionError('');
    try {
      const response = await fetch(`/api/admin/users/${user.user_id}`, { method: 'DELETE', credentials: 'include' });
      await handleAdminResponse(response, 'حذف کاربر ناموفق بود.');
      setSelectedUser(null);
      await loadUsers(usersPage);
      await loadDashboard();
    } catch {
      setActionError('حذف کاربر با خطا مواجه شد. لطفاً دوباره تلاش کنید.');
    }
  };

  const openUser = async (userId: string) => {
    setActionError('');
    try {
      const response = await fetch(`/api/admin/users/${userId}`, { credentials: 'include' });
      const result = await handleAdminResponse(response, 'بارگذاری پروفایل کاربر ناموفق بود.');
      if (result.ok) setSelectedUser(result.data);
    } catch {
      setActionError('اتصال به سرور برقرار نشد. لطفاً دوباره تلاش کنید.');
    }
  };

  const saveConfig = async () => {
    setConfigSaving(true);
    setConfigMessage('');
    try {
      const response = await fetch('/api/admin/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(config)
      });

      if (!response.ok) {
        throw new Error('خطا در ذخیره سازی تنظیمات');
      }

      await loadConfig();
      setConfigMessage('تنظیمات با موفقیت ذخیره شد.');
    } catch (_error) {
      setConfigMessage('ذخیره تنظیمات ناموفق بود. لطفا دوباره تلاش کنید.');
    } finally {
      setConfigSaving(false);
    }
  };

  const downloadReport = () => {
    const params = new URLSearchParams();
    const selectedSections = REPORT_SECTION_OPTIONS
      .filter((section) => reportOptions[section.key])
      .map((section) => section.key);
    if (selectedSections.length === 0) {
      window.alert('حداقل یک بخش گزارش را انتخاب کنید.');
      return;
    }
    params.set('format', reportFormat);
    params.set('sections', selectedSections.join(','));
    const dateRange = getReportDateRange();
    if (dateRange.fromDate) params.set('fromDate', dateRange.fromDate);
    if (dateRange.toDate) params.set('toDate', dateRange.toDate);
    if (reportUserScope === 'selected' && selectedReportUserIds.length > 0) {
      params.set('userIds', selectedReportUserIds.join(','));
    }
    if (reportGuestOnly) params.set('guestOnly', '1');
    if (Number.parseInt(reportMinGuestMessages, 10) > 0) params.set('minGuestMessages', reportMinGuestMessages);
    if (reportGuestErrorsOnly) params.set('guestErrorsOnly', '1');
    if (reportAmbiguousOnly) params.set('ambiguousOnly', '1');
    window.open(`/api/admin/reports/export?${params.toString()}`, '_blank');
  };

  const saveSystemPrompt = async () => {
    if (!systemPrompt.trim()) {
      setSystemPromptMessage('سیستم پرامپت نمی تواند خالی باشد.');
      return;
    }

    setSystemPromptSaving(true);
    setSystemPromptMessage('');
    try {
      const response = await fetch('/api/admin/config/system-prompt', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ systemPrompt })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(payload.error || 'save_failed');
      }
      setSystemPromptMessage(payload.message || 'پرامپت با موفقیت به‌روزرسانی شد');
    } catch (error) {
      setSystemPromptMessage(error instanceof Error ? error.message : 'ذخیره سیستم پرامپت ناموفق بود.');
    } finally {
      setSystemPromptSaving(false);
    }
  };

  const updateLocalPlan = (planId: string, patch: Partial<SubscriptionPlan> & { featuresText?: string }) => {
    setSubscriptions((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        plans: prev.plans.map((plan) => (plan.id === planId ? { ...plan, ...patch } : plan))
      };
    });
  };

  const savePlan = async (plan: SubscriptionPlan) => {
    setSubscriptionSaving(true);
    setSubscriptionMessage('');
    try {
      const response = await fetch(`/api/admin/subscriptions/plans/${encodeURIComponent(plan.id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(plan)
      });
      await handleAdminResponse(response, 'ذخیره پلن ناموفق بود.');
      await loadSubscriptions();
      setSubscriptionMessage('پلن با موفقیت ذخیره شد.');
    } catch (error) {
      setSubscriptionMessage(error instanceof Error ? error.message : 'ذخیره پلن ناموفق بود.');
    } finally {
      setSubscriptionSaving(false);
    }
  };

  const saveLimitPlan = async (plan: SubscriptionPlan) => {
    setLimitsSaving(true);
    setLimitsMessage('');
    try {
      const response = await fetch(`/api/admin/subscriptions/plans/${encodeURIComponent(plan.id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(plan)
      });
      await handleAdminResponse(response, 'ذخیره لیمیت پلن ناموفق بود.');
      await loadSubscriptions();
      setLimitsMessage(`لیمیت‌های پلن «${plan.name}» ذخیره شد.`);
    } catch (error) {
      setLimitsMessage(error instanceof Error ? error.message : 'ذخیره لیمیت پلن ناموفق بود.');
    } finally {
      setLimitsSaving(false);
    }
  };

  const saveGuestLimits = async () => {
    if (!siteSettings) return;
    setLimitsSaving(true);
    setLimitsMessage('');
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ settings: siteSettings.settings })
      });
      const result = await handleAdminResponse(response, 'ذخیره لیمیت مهمان ناموفق بود.');
      if (result.ok) {
        setSiteSettings(result.data);
        await loadAiRuntimeStatus();
        setLimitsMessage('لیمیت‌های مهمان ذخیره شد.');
      }
    } catch (error) {
      setLimitsMessage(error instanceof Error ? error.message : 'ذخیره لیمیت مهمان ناموفق بود.');
    } finally {
      setLimitsSaving(false);
    }
  };

  const applyGuestLimitPreset = (preset: typeof LIMIT_PRESETS[number]) => {
    updateSiteSettingsPatch({
      'guest.message_limit': normalizeLimitValue(preset.message),
      'guest.image_limit_daily': normalizeLimitValue(preset.dailyImage),
      'guest.image_limit_hourly': normalizeLimitValue(preset.hourlyImage),
      'guest.limit_modal.badge_text': preset.message === null ? '∞' : String(preset.message)
    });
  };

  const applyPlanLimitPreset = (planId: string, preset: typeof LIMIT_PRESETS[number]) => {
    updateLocalPlan(planId, {
      dailyMessageLimit: normalizeLimitValue(preset.message),
      dailyImageLimit: normalizeLimitValue(preset.dailyImage),
      hourlyImageLimit: normalizeLimitValue(preset.hourlyImage)
    });
  };

  const assignSubscription = async () => {
    if (!assignForm.userId || !assignForm.planId) {
      setSubscriptionMessage('کاربر و پلن را انتخاب کنید.');
      return;
    }
    setSubscriptionSaving(true);
    setSubscriptionMessage('');
    try {
      const response = await fetch('/api/admin/subscriptions/assign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(assignForm)
      });
      await handleAdminResponse(response, 'اختصاص اشتراک ناموفق بود.');
      await loadSubscriptions();
      setSubscriptionMessage('اشتراک کاربر با موفقیت به‌روزرسانی شد.');
    } catch (error) {
      setSubscriptionMessage(error instanceof Error ? error.message : 'اختصاص اشتراک ناموفق بود.');
    } finally {
      setSubscriptionSaving(false);
    }
  };

  const cancelSubscription = async (userId: string) => {
    if (!window.confirm('اشتراک این کاربر لغو شود؟')) return;
    setSubscriptionSaving(true);
    setSubscriptionMessage('');
    try {
      const response = await fetch(`/api/admin/subscriptions/users/${encodeURIComponent(userId)}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      await handleAdminResponse(response, 'لغو اشتراک ناموفق بود.');
      await loadSubscriptions();
      setSubscriptionMessage('اشتراک لغو شد.');
    } catch (error) {
      setSubscriptionMessage(error instanceof Error ? error.message : 'لغو اشتراک ناموفق بود.');
    } finally {
      setSubscriptionSaving(false);
    }
  };

  const updateSiteSetting = (key: string, value: any) => {
    setSiteSettings((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        settings: {
          ...prev.settings,
          [key]: value
        }
      };
    });
  };

  const updateSiteSettingsPatch = (patch: Record<string, any>) => {
    setSiteSettings((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        settings: {
          ...prev.settings,
          ...patch
        }
      };
    });
  };

  const applyImagePreset = (presetId: string) => {
    const preset = imageModelPresets.find((item) => item.id === presetId) || FALLBACK_IMAGE_MODEL_PRESETS.find((item) => item.id === presetId);
    if (!preset) return;
    updateSiteSettingsPatch({
      'ai.image.model_preset': preset.id,
      'ai.image.provider': preset.provider,
      'ai.image.model': preset.adminValue,
      'ai.image.model.admin_value': preset.adminValue,
      'ai.image.model.runtime_provider_name': preset.runtimeProviderName,
      'ai.image.model.runtime_model': preset.runtimeModel,
      'ai.image.operation': preset.operation,
      'ai.image.resolution': preset.defaultResolution || '1K',
      'ai.image.edit_enabled': Boolean(preset.supportsImageEdit)
    });
  };

  const runImageDryRun = async () => {
    setImageTestLoading(true);
    setImageTestMessage('');
    setImageTestResult(null);
    try {
      const response = await fetch('/api/admin/image-prompt-refiner/test-dry-run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ prompt: imageTestPrompt, settings: siteSettings?.settings || {} })
      });
      const result = await handleAdminResponse(response, 'Dry-run ساخت تصویر ناموفق بود.');
      if (result.ok) {
        setImageTestResult(result.data);
        setImageTestMessage('Dry-run با موفقیت ساخته شد.');
      }
    } catch (error) {
      setImageTestMessage(error instanceof Error ? error.message : 'Dry-run ساخت تصویر ناموفق بود.');
    } finally {
      setImageTestLoading(false);
    }
  };

  const runImageLiveTest = async () => {
    if (!window.confirm('تست واقعی ساخت تصویر اعتبار مصرف می‌کند. ادامه می‌دهی؟')) return;
    setImageTestLoading(true);
    setImageTestMessage('');
    setImageTestResult(null);
    try {
      const response = await fetch('/api/admin/image-prompt-refiner/test-live', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ prompt: imageTestPrompt, settings: siteSettings?.settings || {} })
      });
      const result = await handleAdminResponse(response, 'تست واقعی ساخت تصویر ناموفق بود.');
      if (result.ok) {
        setImageTestResult(result.data);
        setImageTestMessage('تست واقعی با موفقیت انجام شد.');
      }
    } catch (error) {
      setImageTestMessage(error instanceof Error ? error.message : 'تست واقعی ساخت تصویر ناموفق بود.');
    } finally {
      setImageTestLoading(false);
    }
  };

  const runVisionDryRun = async () => {
    setVisionTestLoading(true);
    setVisionTestMessage('');
    setVisionTestResult(null);
    try {
      const response = await fetch('/api/admin/vision/test-dry-run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ prompt: visionTestPrompt, settings: siteSettings?.settings || {} })
      });
      const result = await handleAdminResponse(response, 'Dry-run خواندن تصویر ناموفق بود.');
      if (result.ok) {
        setVisionTestResult(result.data);
        setVisionTestMessage('Dry-run خواندن تصویر با موفقیت ساخته شد.');
      }
    } catch (error) {
      setVisionTestMessage(error instanceof Error ? error.message : 'Dry-run خواندن تصویر ناموفق بود.');
    } finally {
      setVisionTestLoading(false);
    }
  };

  const runVisionLiveTest = async () => {
    if (!visionTestFile) {
      setVisionTestMessage('برای تست واقعی Vision یک تصویر انتخاب کن.');
      return;
    }
    if (!window.confirm('تست واقعی خواندن تصویر ممکن است اعتبار مصرف کند. ادامه می‌دهی؟')) return;
    setVisionTestLoading(true);
    setVisionTestMessage('');
    setVisionTestResult(null);
    try {
      const formData = new FormData();
      formData.append('image', visionTestFile);
      formData.append('prompt', visionTestPrompt);
      formData.append('settings', JSON.stringify(siteSettings?.settings || {}));
      const response = await fetch('/api/admin/vision/test-live', {
        method: 'POST',
        credentials: 'include',
        body: formData
      });
      const result = await handleAdminResponse(response, 'تست واقعی خواندن تصویر ناموفق بود.');
      if (result.ok) {
        setVisionTestResult(result.data);
        setVisionTestMessage('تست واقعی خواندن تصویر با موفقیت انجام شد.');
        await loadAiRuntimeStatus();
      }
    } catch (error) {
      setVisionTestMessage(error instanceof Error ? error.message : 'تست واقعی خواندن تصویر ناموفق بود.');
    } finally {
      setVisionTestLoading(false);
    }
  };

  const runVisionModelProbe = async () => {
    if (!window.confirm('Model probe واقعی ممکن است اعتبار مصرف کند و فقط تصویر تست داخلی را ارسال می‌کند. ادامه می‌دهی؟')) return;
    setVisionTestLoading(true);
    setVisionTestMessage('');
    setVisionTestResult(null);
    try {
      const response = await fetch('/api/admin/vision/model-probe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ settings: siteSettings?.settings || {}, transport: 'inline' })
      });
      const result = await handleAdminResponse(response, 'Model probe خواندن تصویر ناموفق بود.');
      if (result.ok) {
        setVisionTestResult(result.data);
        setVisionTestMessage('Model probe خواندن تصویر با موفقیت انجام شد.');
        await loadAiRuntimeStatus();
      }
    } catch (error) {
      setVisionTestMessage(error instanceof Error ? error.message : 'Model probe خواندن تصویر ناموفق بود.');
    } finally {
      setVisionTestLoading(false);
    }
  };

  const runIntentRouterDryRun = async () => {
    setIntentRouterTestLoading(true);
    setIntentRouterTestMessage('');
    setIntentRouterTestResult(null);
    try {
      const response = await fetch('/api/admin/intent-router/test-dry-run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          userMessage: intentRouterTestPrompt,
          context: {
            hasCurrentImageAttachment: false,
            hasPreviousUploadedImage: false,
            hasPreviousGeneratedImage: true,
            lastImageKind: 'generated',
            locale: 'fa'
          },
          settings: siteSettings?.settings || {}
        })
      });
      const result = await handleAdminResponse(response, 'Dry-run intent-router ناموفق بود.');
      if (result.ok) {
        setIntentRouterTestResult(result.data);
        setIntentRouterTestMessage('Dry-run intent-router با موفقیت انجام شد.');
      }
    } catch (error) {
      setIntentRouterTestMessage(error instanceof Error ? error.message : 'Dry-run intent-router ناموفق بود.');
    } finally {
      setIntentRouterTestLoading(false);
    }
  };

  const runIntentRouterModelProbe = async () => {
    if (!window.confirm('Model probe واقعی intent-router ممکن است اعتبار مصرف کند. ادامه می‌دهی؟')) return;
    setIntentRouterTestLoading(true);
    setIntentRouterTestMessage('');
    setIntentRouterTestResult(null);
    try {
      const response = await fetch('/api/admin/intent-router/model-probe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ settings: siteSettings?.settings || {} })
      });
      const result = await handleAdminResponse(response, 'Model probe intent-router ناموفق بود.');
      if (result.ok) {
        setIntentRouterTestResult(result.data);
        setIntentRouterTestMessage('Model probe intent-router با موفقیت انجام شد.');
        await loadAiRuntimeStatus();
      }
    } catch (error) {
      setIntentRouterTestMessage(error instanceof Error ? error.message : 'Model probe intent-router ناموفق بود.');
    } finally {
      setIntentRouterTestLoading(false);
    }
  };

  const saveSiteSettings = async () => {
    if (!siteSettings) return;
    setSiteSettingsSaving(true);
    setSiteSettingsMessage('');
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ settings: siteSettings.settings })
      });
      const result = await handleAdminResponse(response, 'ذخیره تنظیمات سایت ناموفق بود.');
      if (result.ok) {
        setSiteSettings(result.data);
        await loadAiRuntimeStatus();
        setSiteSettingsMessage('تنظیمات سایت با موفقیت ذخیره شد.');
      }
    } catch (error) {
      setSiteSettingsMessage(error instanceof Error ? error.message : 'ذخیره تنظیمات سایت ناموفق بود.');
    } finally {
      setSiteSettingsSaving(false);
    }
  };

  const updateSupervisedOtpForm = (key: keyof typeof supervisedOtpForm, value: string | boolean) => {
    setSupervisedOtpForm((prev) => ({ ...prev, [key]: value }));
  };

  const saveSupervisedOtp = async () => {
    setSupervisedOtpSaving(true);
    setSupervisedOtpMessage('');
    try {
      const payload: Record<string, unknown> = {
        enabled: supervisedOtpForm.enabled,
        expires_at: supervisedOtpForm.expires_at ? new Date(supervisedOtpForm.expires_at).toISOString() : null,
        max_uses: supervisedOtpForm.max_uses.trim() ? Number(supervisedOtpForm.max_uses) : null
      };
      if (supervisedOtpForm.code.trim()) payload.code = supervisedOtpForm.code.trim();
      const response = await fetch('/api/admin/supervised-otp', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });
      const result = await handleAdminResponse(response, 'ذخیره Supervised OTP ناموفق بود.');
      if (result.ok) {
        const config = result.data as SupervisedOtpConfig;
        setSupervisedOtp(config);
        setSupervisedOtpForm({
          enabled: Boolean(config.enabled),
          code: '',
          expires_at: formatDateTimeLocalInput(config.expires_at),
          max_uses: config.max_uses == null ? '' : String(config.max_uses)
        });
        setSupervisedOtpMessage('Supervised OTP با موفقیت ذخیره شد.');
      }
    } catch (error) {
      setSupervisedOtpMessage(error instanceof Error ? error.message : 'ذخیره Supervised OTP ناموفق بود.');
    } finally {
      setSupervisedOtpSaving(false);
    }
  };

  const resetSupervisedOtpUsedCount = async () => {
    setSupervisedOtpSaving(true);
    setSupervisedOtpMessage('');
    try {
      const response = await fetch('/api/admin/supervised-otp/reset-used-count', {
        method: 'POST',
        credentials: 'include'
      });
      const result = await handleAdminResponse(response, 'ریست تعداد استفاده ناموفق بود.');
      if (result.ok) {
        setSupervisedOtp(result.data);
        setSupervisedOtpMessage('تعداد استفاده ریست شد.');
      }
    } catch (error) {
      setSupervisedOtpMessage(error instanceof Error ? error.message : 'ریست تعداد استفاده ناموفق بود.');
    } finally {
      setSupervisedOtpSaving(false);
    }
  };

  const deleteSupervisedOtp = async () => {
    if (!window.confirm('کد Supervised OTP حذف و غیرفعال شود؟')) return;
    setSupervisedOtpSaving(true);
    setSupervisedOtpMessage('');
    try {
      const response = await fetch('/api/admin/supervised-otp', {
        method: 'DELETE',
        credentials: 'include'
      });
      const result = await handleAdminResponse(response, 'حذف Supervised OTP ناموفق بود.');
      if (result.ok) {
        const config = result.data as SupervisedOtpConfig;
        setSupervisedOtp(config);
        setSupervisedOtpForm({
          enabled: Boolean(config.enabled),
          code: '',
          expires_at: '',
          max_uses: ''
        });
        setSupervisedOtpMessage('Supervised OTP حذف و غیرفعال شد.');
      }
    } catch (error) {
      setSupervisedOtpMessage(error instanceof Error ? error.message : 'حذف Supervised OTP ناموفق بود.');
    } finally {
      setSupervisedOtpSaving(false);
    }
  };

  const supervisedOtpStatus = supervisedOtp?.enabled ? 'فعال' : 'غیرفعال';
  const supervisedOtpHasCode = supervisedOtp?.hasCode ? 'کد ذخیره شده است' : 'کدی ذخیره نشده';
  const supervisedOtpCard = (
    <div className="admin-section supervised-otp-card">
      <div className="admin-section-header">
        <div>
          <h3>Supervised OTP</h3>
          <p className="admin-note">مدیریت کد ۴ رقمی نظارت‌شده برای تایید ورود و ثبت‌نام.</p>
        </div>
        <div className="supervised-otp-card__status">
          <span>{supervisedOtpStatus}</span>
          <strong>{supervisedOtpHasCode}</strong>
        </div>
      </div>

      {supervisedOtpMessage ? (
        <InlineMessage
          text={supervisedOtpMessage}
          variant={supervisedOtpMessage.includes('موفقیت') || supervisedOtpMessage.includes('ریست') || supervisedOtpMessage.includes('حذف') ? 'success' : 'error'}
        />
      ) : null}

      <FieldGroup direction="row">
        <label className="admin-control-field supervised-otp-card__toggle">
          <span>فعال/غیرفعال</span>
          <input
            type="checkbox"
            checked={supervisedOtpForm.enabled}
            onChange={(e) => updateSupervisedOtpForm('enabled', e.target.checked)}
          />
        </label>
        <TextField
          label="کد ۴ رقمی جدید"
          value={supervisedOtpForm.code}
          maxLength={4}
          inputMode="numeric"
          placeholder={supervisedOtp?.hasCode ? 'برای تغییر کد جدید وارد کنید' : 'مثلاً 1234'}
          onChange={(e) => updateSupervisedOtpForm('code', e.target.value.replace(/\D/g, '').slice(0, 4))}
        />
        <TextField
          label="تاریخ انقضا"
          type="datetime-local"
          value={supervisedOtpForm.expires_at}
          onChange={(e) => updateSupervisedOtpForm('expires_at', e.target.value)}
        />
      </FieldGroup>

      <FieldGroup direction="row">
        <TextField
          label="سقف استفاده"
          type="number"
          min="1"
          value={supervisedOtpForm.max_uses}
          placeholder="خالی یعنی نامحدود"
          onChange={(e) => updateSupervisedOtpForm('max_uses', e.target.value)}
        />
        <TextField
          label="تعداد استفاده‌شده"
          value={String(supervisedOtp?.used_count ?? 0)}
          disabled
        />
        <TextField
          label="وضعیت کد"
          value={supervisedOtpHasCode}
          disabled
        />
      </FieldGroup>

      <FieldGroup direction="row" className="config-actions">
        <Button variant="secondary" onClick={() => void saveSupervisedOtp()} disabled={supervisedOtpSaving}>
          {supervisedOtpSaving ? 'در حال ذخیره...' : 'ذخیره'}
        </Button>
        <Button variant="ghost" onClick={() => void resetSupervisedOtpUsedCount()} disabled={supervisedOtpSaving}>
          ریست تعداد استفاده
        </Button>
        <Button variant="ghost" onClick={() => void deleteSupervisedOtp()} disabled={supervisedOtpSaving || !supervisedOtp?.hasCode}>
          حذف/غیرفعال کردن
        </Button>
      </FieldGroup>
    </div>
  );

  return (
    <div className="admin-panel">
      <div className="admin-panel__header">
        <div>
          <span className="admin-panel__eyebrow">مدیریت محصول</span>
          <h2>پنل ادمین دانوآ</h2>
          <p>نمای کلی وضعیت کاربران، اشتراک‌ها، خطاها و فعالیت سیستم</p>
        </div>
      </div>

      <div className="admin-tabs">
        {(Object.keys(TAB_LABELS) as AdminTab[]).map((item) => (
          <Button
            key={item}
            variant="secondary"
            className={`admin-tab ${tab === item ? 'active' : ''}`}
            onClick={() => setTab(item)}
          >
            <span className="admin-tab__icon" aria-hidden="true">{TAB_ICONS[item]}</span>
            {TAB_LABELS[item]}
          </Button>
        ))}
      </div>

      {loadError && (
        <InlineMessage text={loadError} variant="error" />
      )}
      {actionError && (
        <InlineMessage text={actionError} variant="error" />
      )}

      {tab === 'dashboard' ? (
        <div className="admin-section">
          {dashboardLoading ? (
            <div className="dashboard-skeleton">
              <div className="kpi-grid">
                <div className="skeleton-card" />
                <div className="skeleton-card" />
                <div className="skeleton-card" />
                <div className="skeleton-card" />
              </div>
              <div className="chart-grid">
                <div className="skeleton-chart" />
                <div className="skeleton-chart" />
                <div className="skeleton-chart" />
              </div>
            </div>
          ) : null}
          {dashboardError ? <p className="admin-error">{dashboardError}</p> : null}

          {dashboard ? (
            <>
              <div className="kpi-grid">
                <div className="kpi-card kpi-card--users">
                  <div className="kpi-card__label">تعداد کل کاربران</div>
                  <strong className="kpi-card__value">{dashboard.kpis.totalUsers}</strong>
                </div>
                <div className="kpi-card kpi-card--active">
                  <div className="kpi-card__label">کاربران فعال 24 ساعت اخیر</div>
                  <strong className="kpi-card__value">{dashboard.kpis.activeUsersToday}</strong>
                </div>
                <div className="kpi-card kpi-card--api">
                  <div className="kpi-card__label">درخواست های API امروز</div>
                  <strong className="kpi-card__value">{dashboard.kpis.apiCallsToday}</strong>
                </div>
                <div className="kpi-card kpi-card--errors">
                  <div className="kpi-card__label">تعداد خطاهای امروز</div>
                  <strong className="kpi-card__value">{dashboard.kpis.errorCountToday}</strong>
                </div>
              </div>

              <div className="chart-grid">
                <div className="chart-card">
                  <h3>رشد کاربران - 7 روز اخیر</h3>
                  <ResponsiveContainer width="100%" height="90%">
                    <LineChart data={dashboard.userGrowth}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="users" stroke="#2563eb" strokeWidth={2} name="کاربر جدید" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="chart-card">
                  <h3>مصرف API - 7 روز اخیر</h3>
                  <ResponsiveContainer width="100%" height="90%">
                    <BarChart data={dashboard.apiUsage}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="calls" fill="#16a34a" name="message_sent" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="chart-card">
                  <h3>توزیع خطاها</h3>
                  <ResponsiveContainer width="100%" height="90%">
                    <PieChart>
                      <Pie
                        data={dashboard.errorDistribution}
                        dataKey="count"
                        nameKey="error_type"
                        cx="50%"
                        cy="50%"
                        outerRadius={95}
                        label
                      >
                        {dashboard.errorDistribution.map((item, index) => (
                          <Cell key={`${item.error_type}-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="admin-section">
                <h3>آخرین فعالیت ها (Audit)</h3>
                <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>زمان</th>
                      <th>ادمین</th>
                      <th>عملیات</th>
                      <th>هدف</th>
                      <th>جزئیات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dashboard.recentActivities.map((item, index) => (
                      <tr key={index}>
                        <td>{item.timestamp || '-'}</td>
                        <td>{item.adminUsername || '-'}</td>
                        <td>{item.action || '-'}</td>
                        <td>{item.target || '-'}</td>
                        <td>{JSON.stringify(item.details || {})}</td>
                      </tr>
                    ))}
                    {dashboard.recentActivities.length === 0 ? (
                      <tr>
                        <td colSpan={5}>هنوز فعالیتی ثبت نشده است.</td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
                </div>
              </div>
            </>
          ) : null}
        </div>
      ) : null}

      {tab === 'users' ? (
        <div className="admin-section">
          <div className="admin-controls">
            <TextField
              className="admin-control-field"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="جستجوی نام"
              aria-label="جستجوی نام"
              fullWidth={false}
            />
            <select value={banFilter} onChange={(e) => setBanFilter(e.target.value)}>
              <option value="all">همه</option>
              <option value="true">مسدود</option>
              <option value="false">فعال</option>
            </select>
            <Button className="admin-action-btn" onClick={handleApplyUserFilters}>اعمال فیلتر</Button>
          </div>
          <div className="admin-users-summary">
            <span>
              نمایش صفحه {usersPage} از {usersTotalPages}، مجموع {usersTotal} کاربر
            </span>
            <span>
              {selectedReportUserIds.length > 0
                ? `${selectedReportUserIds.length} کاربر برای گزارش انتخاب شده`
                : 'برای گزارش چندنفره، کاربران را از جدول انتخاب کنید.'}
            </span>
          </div>
          <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>
                  <input
                    type="checkbox"
                    checked={isEveryVisibleUserSelected}
                    onChange={toggleVisibleReportUsers}
                    aria-label="انتخاب همه کاربران این صفحه برای گزارش"
                  />
                </th>
                <th>نام</th><th>سن</th><th>شماره</th><th>تاریخ عضویت</th><th>تعداد گفتگو</th><th>آخرین فعالیت</th><th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              {visibleUsers.map((user) => (
                <tr key={user.user_id}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selectedReportUserIds.includes(user.user_id)}
                      onChange={() => toggleReportUser(user.user_id)}
                      aria-label={`انتخاب ${user.name} برای گزارش`}
                    />
                  </td>
                  <td>{user.name}</td><td>{user.age}</td><td>{user.phone || '-'}</td><td>{user.registered_at || '-'}</td>
                  <td>{user.conversationCount || 0}</td><td>{user.last_activity || '-'}</td>
                  <td>
                    <FieldGroup direction="row" className="admin-row-actions">
                      <Button variant="ghost" size="sm" onClick={() => void openUser(user.user_id)}>
                        پروفایل
                      </Button>
                      <Button variant="secondary" size="sm" onClick={() => void toggleBan(user)}>
                        {user.isBanned ? 'رفع مسدود' : 'مسدود'}
                      </Button>
                      <Button variant="danger" size="sm" onClick={() => void deleteUser(user)}>
                        حذف
                      </Button>
                    </FieldGroup>
                  </td>
                </tr>
              ))}
              {visibleUsers.length === 0 ? (
                <tr><td colSpan={8}>کاربری با این فیلتر پیدا نشد.</td></tr>
              ) : null}
            </tbody>
          </table>
          </div>
          <div className="admin-pagination">
            <Button
              variant="secondary"
              size="sm"
              disabled={usersPage <= 1}
              onClick={() => handleUsersPageChange(usersPage - 1)}
            >
              قبلی
            </Button>
            <span>صفحه {usersPage} / {usersTotalPages}</span>
            <Button
              variant="secondary"
              size="sm"
              disabled={usersPage >= usersTotalPages}
              onClick={() => handleUsersPageChange(usersPage + 1)}
            >
              بعدی
            </Button>
          </div>

          {selectedUser ? (
            <div className="profile-box">
              <h3>پروفایل کاربر: {selectedUser.name}</h3>
              <p>سن: {selectedUser.age} | شماره: {selectedUser.phone || '-'}</p>
              {selectedUser.conversations.map((conv) => (
                <details key={conv.conversation_id} className="profile-conversation">
                  <summary>{conv.title} - {conv.message_count} پیام</summary>
                  <div className="profile-messages">
                    {conv.messages.map((msg, index) => {
                      const images = getProfileMessageImages(msg, selectedUser.user_id);
                      return (
                        <article className={`profile-message profile-message--${msg.role}`} key={`${conv.conversation_id}-${index}`}>
                          <div className="profile-message__meta">
                            <strong>{msg.role === 'user' ? 'کاربر' : 'دانوآ'}</strong>
                            {msg.timestamp ? <span>{msg.timestamp}</span> : null}
                            {msg.type && msg.type !== 'text' ? <span>{msg.type}</span> : null}
                            {msg.status ? <span>{msg.status}</span> : null}
                          </div>
                          {msg.content ? <p>{msg.content}</p> : null}
                          {images.length > 0 ? (
                            <div className="profile-message-images">
                              {images.map((image) => (
                                <a key={image.url} href={image.url} target="_blank" rel="noreferrer">
                                  <img src={image.url} alt={image.alt || 'تصویر گفتگو'} loading="lazy" />
                                </a>
                              ))}
                            </div>
                          ) : null}
                        </article>
                      );
                    })}
                    {conv.messages.length === 0 ? <p className="admin-note">پیامی در این گفتگو نیست.</p> : null}
                  </div>
                </details>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}

      {tab === 'limits' ? (
        <div className="admin-section limits-center">
          <div className="admin-section-header limits-center__header">
            <div>
              <h3>مرکز کنترل لیمیت‌ها</h3>
              <p className="admin-note">
                لیمیت مهمان‌ها و همه اشتراک‌های فعلی از اینجا مدیریت می‌شود. هر پلنی که بعداً به سایت اضافه شود، خودکار در همین لیست دیده می‌شود.
              </p>
            </div>
            <FieldGroup direction="row" className="limits-center__actions">
              <Button className="admin-action-btn" onClick={() => { void loadSubscriptions(); void loadSiteSettings(); }}>
                بروزرسانی
              </Button>
            </FieldGroup>
          </div>

          {limitsMessage ? (
            <InlineMessage
              text={limitsMessage}
              variant={limitsMessage.includes('ذخیره شد') ? 'success' : 'error'}
            />
          ) : null}

          <div className="limits-overview-grid">
            <div className={`limits-overview-card tone-${guestLimitTone}`}>
              <span>مهمان‌ها</span>
              <strong>{formatLimitLabel(siteSettings?.settings?.['guest.message_limit'] ?? 10, 'پیام')}</strong>
              <small>تصویر روزانه: {formatLimitLabel(siteSettings?.settings?.['guest.image_limit_daily'] ?? 0, 'تصویر')}</small>
            </div>
            <div className="limits-overview-card">
              <span>پلن‌های فعال</span>
              <strong>{new Intl.NumberFormat('fa-IR').format(activePlansCount)}</strong>
              <small>از {new Intl.NumberFormat('fa-IR').format(sortedPlans.length)} پلن ثبت‌شده</small>
            </div>
            <div className="limits-overview-card">
              <span>کاربران دارای اشتراک</span>
              <strong>{new Intl.NumberFormat('fa-IR').format(subscriptions?.userSubscriptions?.length || 0)}</strong>
              <small>بر اساس لیست اشتراک‌های فعال/ثبت‌شده</small>
            </div>
          </div>

          <div className="limits-help-strip">
            <span>راهنما</span>
            <p>خالی یعنی نامحدود، عدد ۰ یعنی آن قابلیت کامل غیرفعال می‌شود، عدد مثبت یعنی سقف مصرف در همان بازه.</p>
          </div>

          <article className="limit-rule-card limit-rule-card--guest">
            <div className="limit-rule-card__head">
              <div>
                <span className="limit-rule-card__eyebrow">Guest policy</span>
                <h4>مهمان‌ها</h4>
                <p>قبل از ثبت‌نام یا ورود، این محدودیت‌ها روی چت و ساخت تصویر مهمان اعمال می‌شود.</p>
              </div>
              <strong className={`limit-status-pill tone-${guestLimitTone}`}>
                {guestLimitTone === 'blocked' ? 'بسته' : guestLimitTone === 'unlimited' ? 'نامحدود' : 'محدود'}
              </strong>
            </div>

            <div className="limit-preset-row">
              {LIMIT_PRESETS.map((preset) => (
                <button key={preset.id} type="button" onClick={() => applyGuestLimitPreset(preset)}>
                  {preset.label}
                </button>
              ))}
            </div>

            {siteSettings ? (
              <>
                <FieldGroup direction="row">
                  <TextField
                    label="سقف پیام مهمان"
                    type="number"
                    value={String(siteSettings.settings['guest.message_limit'] ?? 10)}
                    helperText="برای مهمان عدد مشخص بگذار؛ این مقدار سقف کل گفتگوی مهمان است."
                    onChange={(e) => updateSiteSetting('guest.message_limit', Math.max(0, Number(e.target.value) || 0))}
                  />
                  <TextField
                    label="سقف تصویر روزانه مهمان"
                    value={siteSettings.settings['guest.image_limit_daily'] === null ? '' : String(siteSettings.settings['guest.image_limit_daily'] ?? 0)}
                    placeholder="خالی = نامحدود، ۰ = غیرفعال"
                    onChange={(e) => updateSiteSetting('guest.image_limit_daily', parseNullableNumberInput(e.target.value))}
                  />
                  <TextField
                    label="سقف تصویر ساعتی مهمان"
                    value={siteSettings.settings['guest.image_limit_hourly'] === null ? '' : String(siteSettings.settings['guest.image_limit_hourly'] ?? 0)}
                    placeholder="خالی = نامحدود، ۰ = غیرفعال"
                    onChange={(e) => updateSiteSetting('guest.image_limit_hourly', parseNullableNumberInput(e.target.value))}
                  />
                </FieldGroup>
                <FieldGroup direction="row">
                  <TextField
                    label="نشان مودال لیمیت"
                    value={String(siteSettings.settings['guest.limit_modal.badge_text'] ?? '')}
                    onChange={(e) => updateSiteSetting('guest.limit_modal.badge_text', e.target.value)}
                  />
                  <TextField
                    label="متن دکمه مودال"
                    value={String(siteSettings.settings['guest.limit_modal.cta'] ?? '')}
                    onChange={(e) => updateSiteSetting('guest.limit_modal.cta', e.target.value)}
                  />
                </FieldGroup>
                <TextAreaField
                  label="پیام مودال وقتی مهمان به سقف می‌رسد"
                  rows={3}
                  value={String(siteSettings.settings['guest.limit_modal.body'] ?? '')}
                  onChange={(e) => updateSiteSetting('guest.limit_modal.body', e.target.value)}
                />
                <Button className="admin-action-btn" disabled={limitsSaving} onClick={() => void saveGuestLimits()}>
                  ذخیره لیمیت مهمان
                </Button>
              </>
            ) : (
              <p className="admin-note">تنظیمات مهمان هنوز بارگذاری نشده است.</p>
            )}
          </article>

          <div className="limit-plan-grid">
            {sortedPlans.map((plan) => {
              const tone = getLimitTone(plan.dailyMessageLimit, plan.dailyImageLimit, plan.hourlyImageLimit);
              return (
                <article className={`limit-rule-card tone-${tone}`} key={plan.id}>
                  <div className="limit-rule-card__head">
                    <div>
                      <span className="limit-rule-card__eyebrow">{plan.id}</span>
                      <h4>{plan.icon} {plan.name}</h4>
                      <p>{plan.tagline || 'قوانین مصرف این اشتراک را تنظیم کن.'}</p>
                    </div>
                    <strong className={`limit-status-pill tone-${tone}`}>
                      {tone === 'blocked' ? 'قابلیت بسته' : tone === 'unlimited' ? 'نامحدود' : 'دارای سقف'}
                    </strong>
                  </div>

                  <div className="limit-card-summary">
                    <span>{formatLimitLabel(plan.dailyMessageLimit, 'پیام/روز')}</span>
                    <span>{formatLimitLabel(plan.dailyImageLimit, 'تصویر/روز')}</span>
                    <span>{formatLimitLabel(plan.hourlyImageLimit, 'تصویر/ساعت')}</span>
                  </div>

                  <div className="limit-preset-row">
                    {LIMIT_PRESETS.map((preset) => (
                      <button key={preset.id} type="button" onClick={() => applyPlanLimitPreset(plan.id, preset)}>
                        {preset.label}
                      </button>
                    ))}
                  </div>

                  <FieldGroup direction="row">
                    <TextField
                      label="پیام روزانه"
                      value={plan.dailyMessageLimit === null ? '' : String(plan.dailyMessageLimit)}
                      placeholder="خالی = نامحدود"
                      onChange={(e) => updateLocalPlan(plan.id, { dailyMessageLimit: parseNullableNumberInput(e.target.value) })}
                    />
                    <TextField
                      label="تصویر روزانه"
                      value={plan.dailyImageLimit === null ? '' : String(plan.dailyImageLimit)}
                      placeholder="خالی = نامحدود، ۰ = خاموش"
                      onChange={(e) => updateLocalPlan(plan.id, { dailyImageLimit: parseNullableNumberInput(e.target.value) })}
                    />
                    <TextField
                      label="تصویر ساعتی"
                      value={plan.hourlyImageLimit === null ? '' : String(plan.hourlyImageLimit)}
                      placeholder="خالی = نامحدود، ۰ = خاموش"
                      onChange={(e) => updateLocalPlan(plan.id, { hourlyImageLimit: parseNullableNumberInput(e.target.value) })}
                    />
                  </FieldGroup>

                  <FieldGroup direction="row">
                    <TextField
                      label="ترتیب نمایش"
                      type="number"
                      value={String(plan.sortOrder || 999)}
                      onChange={(e) => updateLocalPlan(plan.id, { sortOrder: Number(e.target.value) || 999 })}
                    />
                    <label className="admin-select-field">
                      <span>وضعیت پلن</span>
                      <select
                        value={plan.isActive ? 'true' : 'false'}
                        onChange={(e) => updateLocalPlan(plan.id, { isActive: e.target.value === 'true' })}
                      >
                        <option value="true">فعال در سایت</option>
                        <option value="false">غیرفعال</option>
                      </select>
                    </label>
                  </FieldGroup>

                  <Button className="admin-action-btn" disabled={limitsSaving} onClick={() => void saveLimitPlan(plan)}>
                    ذخیره لیمیت این پلن
                  </Button>
                </article>
              );
            })}
          </div>

          {sortedPlans.length === 0 ? (
            <p className="admin-note">هنوز پلنی برای نمایش وجود ندارد.</p>
          ) : null}
        </div>
      ) : null}

      {tab === 'subscriptions' ? (
        <div className="admin-section">
          <div className="admin-section-header">
            <div>
              <h3>مدیریت اشتراک‌ها</h3>
              <p className="admin-note">پلن‌های نمایش داده‌شده در صفحه خرید و اشتراک فعال کاربران را مدیریت کنید.</p>
            </div>
            <Button className="admin-action-btn" onClick={() => void loadSubscriptions()}>بروزرسانی</Button>
          </div>

          {subscriptionMessage ? (
            <InlineMessage
              text={subscriptionMessage}
              variant={subscriptionMessage.includes('موفقیت') || subscriptionMessage.includes('لغو شد') ? 'success' : 'error'}
            />
          ) : null}

          <div className="subscription-plan-grid">
            {(subscriptions?.plans || []).map((plan) => (
              <article className="subscription-plan-editor" key={plan.id}>
                <div className="subscription-plan-editor__head">
                  <strong>{plan.icon} {plan.name}</strong>
                  <label>
                    <input
                      type="checkbox"
                      checked={plan.isActive}
                      onChange={(event) => updateLocalPlan(plan.id, { isActive: event.target.checked })}
                    />
                    فعال
                  </label>
                </div>
                <FieldGroup direction="row">
                  <TextField label="نام پلن" value={plan.name} onChange={(e) => updateLocalPlan(plan.id, { name: e.target.value })} />
                  <TextField label="آیکن" value={plan.icon} onChange={(e) => updateLocalPlan(plan.id, { icon: e.target.value })} />
                </FieldGroup>
                <TextField label="توضیح کوتاه" value={plan.tagline || ''} onChange={(e) => updateLocalPlan(plan.id, { tagline: e.target.value })} />
                <FieldGroup direction="row">
                  <TextField label="قیمت ماهانه" type="number" value={String(plan.monthlyPrice || 0)} onChange={(e) => updateLocalPlan(plan.id, { monthlyPrice: Number(e.target.value) })} />
                  <TextField label="قیمت روزانه" type="number" value={String(plan.dailyPrice || 0)} onChange={(e) => updateLocalPlan(plan.id, { dailyPrice: Number(e.target.value) })} />
                </FieldGroup>
                <FieldGroup direction="row">
                  <TextField
                    label="سقف پیام روزانه"
                    value={plan.dailyMessageLimit === null ? '' : String(plan.dailyMessageLimit)}
                    placeholder="خالی = نامحدود"
                    onChange={(e) => updateLocalPlan(plan.id, { dailyMessageLimit: e.target.value.trim() ? Number(e.target.value) : null })}
                  />
                  <TextField
                    label="سقف تصویر روزانه"
                    value={plan.dailyImageLimit === null ? '' : String(plan.dailyImageLimit)}
                    placeholder="خالی = نامحدود، ۰ = غیرفعال"
                    helperText="خالی = نامحدود، ۰ = غیرفعال، عدد مثبت = سقف مجاز"
                    onChange={(e) => updateLocalPlan(plan.id, { dailyImageLimit: parseNullableNumberInput(e.target.value) })}
                  />
                  <TextField
                    label="سقف تصویر ساعتی"
                    value={plan.hourlyImageLimit === null ? '' : String(plan.hourlyImageLimit)}
                    placeholder="خالی = نامحدود، ۰ = غیرفعال"
                    helperText="خالی = نامحدود، ۰ = غیرفعال، عدد مثبت = سقف مجاز"
                    onChange={(e) => updateLocalPlan(plan.id, { hourlyImageLimit: parseNullableNumberInput(e.target.value) })}
                  />
                </FieldGroup>
                <TextAreaField
                  label="ویژگی‌ها"
                  rows={4}
                  value={plan.features.join('\n')}
                  onChange={(e) => updateLocalPlan(plan.id, { features: e.target.value.split('\n').map((item) => item.trim()).filter(Boolean) })}
                  helperText="هر ویژگی در یک خط"
                />
                <Button className="admin-action-btn" disabled={subscriptionSaving} onClick={() => void savePlan(plan)}>
                  ذخیره پلن
                </Button>
              </article>
            ))}
          </div>

          <div className="subscription-assign-panel">
            <h3>اختصاص اشتراک به کاربر</h3>
            <FieldGroup direction="row">
              <label className="admin-select-field">
                <span>کاربر</span>
                <select value={assignForm.userId} onChange={(e) => setAssignForm({ ...assignForm, userId: e.target.value })}>
                  {(subscriptions?.users || users).map((user) => (
                    <option key={user.user_id} value={user.user_id}>
                      {user.name} - {user.phone || user.user_id}
                    </option>
                  ))}
                </select>
              </label>
              <label className="admin-select-field">
                <span>پلن</span>
                <select value={assignForm.planId} onChange={(e) => setAssignForm({ ...assignForm, planId: e.target.value })}>
                  {(subscriptions?.plans || []).map((plan) => (
                    <option key={plan.id} value={plan.id}>{plan.name}</option>
                  ))}
                </select>
              </label>
            </FieldGroup>
            <FieldGroup direction="row">
              <TextField
                label="تاریخ انقضا"
                type="date"
                value={assignForm.expiresAt}
                onChange={(e) => setAssignForm({ ...assignForm, expiresAt: e.target.value })}
                helperText="خالی بماند یعنی بدون تاریخ انقضا"
              />
              <TextField
                label="یادداشت"
                value={assignForm.note}
                onChange={(e) => setAssignForm({ ...assignForm, note: e.target.value })}
              />
            </FieldGroup>
            <Button className="admin-action-btn" disabled={subscriptionSaving} onClick={() => void assignSubscription()}>
              ثبت اشتراک کاربر
            </Button>
          </div>

          <h3>اشتراک‌های فعال</h3>
          <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr><th>کاربر</th><th>پلن</th><th>وضعیت</th><th>شروع</th><th>انقضا</th><th>عملیات</th></tr>
            </thead>
            <tbody>
              {(subscriptions?.userSubscriptions || []).map((item) => (
                <tr key={item.userId}>
                  <td>{item.user?.name || item.userId}</td>
                  <td>{item.plan?.name || item.planId}</td>
                  <td>{item.status === 'active' ? 'فعال' : item.status}</td>
                  <td>{item.assignedAt || '-'}</td>
                  <td>{item.expiresAt || 'بدون انقضا'}</td>
                  <td>
                    <Button variant="danger" size="sm" onClick={() => void cancelSubscription(item.userId)}>
                      لغو
                    </Button>
                  </td>
                </tr>
              ))}
              {(!subscriptions?.userSubscriptions || subscriptions.userSubscriptions.length === 0) ? (
                <tr><td colSpan={6}>هنوز اشتراک فعالی ثبت نشده است.</td></tr>
              ) : null}
            </tbody>
          </table>
          </div>
        </div>
      ) : null}

      {tab === 'siteSettings' ? (
        <div className="admin-section config-panel">
          <h3>تنظیمات سایت</h3>
          <p className="admin-note">فقط تنظیمات غیرحساس در این بخش ذخیره می‌شوند. کلیدهای API و رمزها همچنان فقط در env می‌مانند.</p>

          {siteSettingsMessage ? (
            <InlineMessage
              text={siteSettingsMessage}
              variant={siteSettingsMessage.includes('موفقیت') ? 'success' : 'error'}
            />
          ) : null}

          {siteSettings ? (
            <>
              <h4>مهمان</h4>
              <FieldGroup direction="row">
                <TextField
                  label="تعداد پیام مهمان"
                  type="number"
                  value={String(siteSettings.settings['guest.message_limit'] ?? 10)}
                  onChange={(e) => updateSiteSetting('guest.message_limit', Number(e.target.value))}
                />
              </FieldGroup>
              <FieldGroup direction="row">
                <TextField
                  label="سقف تصویر روزانه مهمان"
                  value={siteSettings.settings['guest.image_limit_daily'] === null ? '' : String(siteSettings.settings['guest.image_limit_daily'] ?? '')}
                  placeholder="خالی = نامحدود، ۰ = غیرفعال"
                  onChange={(e) => updateSiteSetting('guest.image_limit_daily', parseNullableNumberInput(e.target.value))}
                />
                <TextField
                  label="سقف تصویر ساعتی مهمان"
                  value={siteSettings.settings['guest.image_limit_hourly'] === null ? '' : String(siteSettings.settings['guest.image_limit_hourly'] ?? '')}
                  placeholder="خالی = نامحدود، ۰ = غیرفعال"
                  onChange={(e) => updateSiteSetting('guest.image_limit_hourly', parseNullableNumberInput(e.target.value))}
                />
              </FieldGroup>
              <FieldGroup direction="row">
                <TextField
                  label="نشان مودال"
                  value={String(siteSettings.settings['guest.limit_modal.badge_text'] ?? '')}
                  onChange={(e) => updateSiteSetting('guest.limit_modal.badge_text', e.target.value)}
                />
              </FieldGroup>
              <FieldGroup direction="row">
                <TextField
                  label="عنوان مودال"
                  value={String(siteSettings.settings['guest.limit_modal.title'] ?? '')}
                  onChange={(e) => updateSiteSetting('guest.limit_modal.title', e.target.value)}
                />
                <TextField
                  label="تیتر مودال"
                  value={String(siteSettings.settings['guest.limit_modal.heading'] ?? '')}
                  onChange={(e) => updateSiteSetting('guest.limit_modal.heading', e.target.value)}
                />
              </FieldGroup>
              <TextAreaField
                label="متن مودال محدودیت مهمان"
                rows={3}
                value={String(siteSettings.settings['guest.limit_modal.body'] ?? '')}
                onChange={(e) => updateSiteSetting('guest.limit_modal.body', e.target.value)}
              />
              <TextField
                label="متن دکمه مودال"
                value={String(siteSettings.settings['guest.limit_modal.cta'] ?? '')}
                onChange={(e) => updateSiteSetting('guest.limit_modal.cta', e.target.value)}
              />

              <h4>آپلود عکس</h4>
              <FieldGroup direction="row">
                <TextField
                  label="حداکثر حجم عکس (MB)"
                  type="number"
                  value={String(siteSettings.settings['upload.image.max_size_mb'] ?? 5)}
                  onChange={(e) => updateSiteSetting('upload.image.max_size_mb', Number(e.target.value))}
                />
                <TextField
                  label="حداکثر تعداد عکس"
                  type="number"
                  value={String(siteSettings.settings['upload.image.max_files'] ?? 5)}
                  onChange={(e) => updateSiteSetting('upload.image.max_files', Number(e.target.value))}
                />
              </FieldGroup>
              <TextField
                label="فرمت‌های مجاز عکس"
                value={Array.isArray(siteSettings.settings['upload.image.allowed_types']) ? siteSettings.settings['upload.image.allowed_types'].join(', ') : ''}
                onChange={(e) => updateSiteSetting('upload.image.allowed_types', e.target.value.split(',').map((item) => item.trim()).filter(Boolean))}
                helperText="مقادیر مجاز: image/jpeg, image/png, image/webp"
              />

              <h4>تنظیمات چت</h4>
              <FieldGroup direction="row">
                <TextField
                  label="مدل چت"
                  value={String(siteSettings.settings['ai.chat.model'] ?? '')}
                  onChange={(e) => updateSiteSetting('ai.chat.model', e.target.value)}
                />
                <TextField
                  label="Temperature"
                  type="number"
                  step="0.1"
                  value={String(siteSettings.settings['ai.chat.temperature'] ?? 0.6)}
                  onChange={(e) => updateSiteSetting('ai.chat.temperature', Number(e.target.value))}
                />
                <TextField
                  label="Timeout (ms)"
                  type="number"
                  value={String(siteSettings.settings['ai.chat.timeout_ms'] ?? 30000)}
                  onChange={(e) => updateSiteSetting('ai.chat.timeout_ms', Number(e.target.value))}
                />
              </FieldGroup>
              {aiRuntimeStatus ? (
                <p className="admin-note">
                  Runtime چت: provider={aiRuntimeStatus.chat.provider}، model={aiRuntimeStatus.chat.model || '-'}، host={aiRuntimeStatus.chat.baseUrlHost || '-'}، key source={aiRuntimeStatus.chat.apiKeySource}، fingerprint={aiRuntimeStatus.chat.apiKeyFingerprint || '-'}
                </p>
              ) : null}

              <h4>Intent Router</h4>
              {aiRuntimeStatus?.intentRouter ? (
                <p className="admin-note">
                  Runtime intent-router: enabled={aiRuntimeStatus.intentRouter.enabled ? 'true' : 'false'}، provider={aiRuntimeStatus.intentRouter.provider}، model={aiRuntimeStatus.intentRouter.model}، fallback={aiRuntimeStatus.intentRouter.fallbackModel}، experimental={aiRuntimeStatus.intentRouter.experimentalModel}، key source={aiRuntimeStatus.intentRouter.apiKeySource}، key={aiRuntimeStatus.intentRouter.apiKeySet ? 'set' : 'missing'}، fingerprint={aiRuntimeStatus.intentRouter.apiKeyFingerprint || '-'}، threshold={aiRuntimeStatus.intentRouter.confidenceThreshold}، timeout={aiRuntimeStatus.intentRouter.timeoutMs}، heuristic fallback={aiRuntimeStatus.intentRouter.fallbackToHeuristic ? 'true' : 'false'}، validation={aiRuntimeStatus.intentRouter.lastValidationStatus || '-'}
                </p>
              ) : null}
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Intent router</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.intent_router.enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.intent_router.enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Provider</span>
                  <select
                    value={String(siteSettings.settings['ai.intent_router.provider'] ?? 'metis')}
                    onChange={(e) => updateSiteSetting('ai.intent_router.provider', e.target.value)}
                  >
                    <option value="metis">metis</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Primary model</span>
                  <select
                    value={String(siteSettings.settings['ai.intent_router.model'] ?? 'gemini-2.5-flash-lite-preview')}
                    onChange={(e) => updateSiteSetting('ai.intent_router.model', e.target.value)}
                  >
                    {INTENT_ROUTER_MODEL_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Fallback model</span>
                  <select
                    value={String(siteSettings.settings['ai.intent_router.fallback_model'] ?? 'gemini-2.5-flash')}
                    onChange={(e) => updateSiteSetting('ai.intent_router.fallback_model', e.target.value)}
                  >
                    {INTENT_ROUTER_MODEL_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Experimental model</span>
                  <select
                    value={String(siteSettings.settings['ai.intent_router.experimental_model'] ?? 'gemini-2.5-flash-lite-preview')}
                    onChange={(e) => updateSiteSetting('ai.intent_router.experimental_model', e.target.value)}
                  >
                    {INTENT_ROUTER_MODEL_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
              </FieldGroup>
              <FieldGroup direction="row">
                <TextField
                  label="Temperature"
                  type="number"
                  step="0.1"
                  value={String(siteSettings.settings['ai.intent_router.temperature'] ?? 0)}
                  onChange={(e) => updateSiteSetting('ai.intent_router.temperature', Number(e.target.value))}
                />
                <TextField
                  label="Max output tokens"
                  type="number"
                  value={String(siteSettings.settings['ai.intent_router.max_output_tokens'] ?? 120)}
                  onChange={(e) => updateSiteSetting('ai.intent_router.max_output_tokens', Number(e.target.value))}
                />
                <TextField
                  label="Timeout ms"
                  type="number"
                  value={String(siteSettings.settings['ai.intent_router.timeout_ms'] ?? 2500)}
                  onChange={(e) => updateSiteSetting('ai.intent_router.timeout_ms', Number(e.target.value))}
                />
                <TextField
                  label="Confidence threshold"
                  type="number"
                  step="0.01"
                  value={String(siteSettings.settings['ai.intent_router.confidence_threshold'] ?? 0.65)}
                  onChange={(e) => updateSiteSetting('ai.intent_router.confidence_threshold', Number(e.target.value))}
                />
              </FieldGroup>
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Heuristic fallback</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.intent_router.fallback_to_heuristic'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.intent_router.fallback_to_heuristic', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Model fallback</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.intent_router.allow_model_fallback'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.intent_router.allow_model_fallback', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Chat key fallback</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.intent_router.allow_chat_key_fallback'] ?? false))}
                    onChange={(e) => updateSiteSetting('ai.intent_router.allow_chat_key_fallback', e.target.value === 'true')}
                  >
                    <option value="false">غیرفعال</option>
                    <option value="true">فعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Store metadata</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.intent_router.store_metadata'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.intent_router.store_metadata', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
              </FieldGroup>
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Model health</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.intent_router.model_health.enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.intent_router.model_health.enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <TextField
                  label="Health failure threshold"
                  type="number"
                  value={String(siteSettings.settings['ai.intent_router.model_health.failure_threshold'] ?? 3)}
                  onChange={(e) => updateSiteSetting('ai.intent_router.model_health.failure_threshold', Number(e.target.value))}
                />
                <TextField
                  label="Health cooldown minutes"
                  type="number"
                  value={String(siteSettings.settings['ai.intent_router.model_health.cooldown_minutes'] ?? 60)}
                  onChange={(e) => updateSiteSetting('ai.intent_router.model_health.cooldown_minutes', Number(e.target.value))}
                />
              </FieldGroup>
              {aiRuntimeStatus?.intentRouter?.health?.models ? (
                <pre className="admin-json-preview">{JSON.stringify(aiRuntimeStatus.intentRouter.health.models, null, 2)}</pre>
              ) : null}
              <TextAreaField
                label="Intent router system prompt"
                rows={7}
                value={String(siteSettings.settings['ai.intent_router.system_prompt'] ?? INTENT_ROUTER_DEFAULT_SYSTEM_PROMPT)}
                onChange={(e) => updateSiteSetting('ai.intent_router.system_prompt', e.target.value)}
              />
              <FieldGroup direction="row">
                <TextField
                  label="Prompt تست intent-router"
                  value={intentRouterTestPrompt}
                  onChange={(e) => setIntentRouterTestPrompt(e.target.value)}
                />
                <Button onClick={() => void runIntentRouterDryRun()} disabled={intentRouterTestLoading}>
                  تست intent-router Dry-run
                </Button>
                <Button variant="secondary" onClick={() => void runIntentRouterModelProbe()} disabled={intentRouterTestLoading}>
                  تست Model Probe
                </Button>
              </FieldGroup>
              {intentRouterTestMessage ? (
                <InlineMessage text={intentRouterTestMessage} variant={intentRouterTestMessage.includes('موفقیت') ? 'success' : 'error'} />
              ) : null}
              {intentRouterTestResult ? (
                <pre className="admin-json-preview">{JSON.stringify(intentRouterTestResult, null, 2)}</pre>
              ) : null}

              <h4>تنظیمات ساخت تصویر</h4>
              {aiRuntimeStatus ? (
                <p className="admin-note">
                  Runtime تصویر: enabled={aiRuntimeStatus.image.enabled ? 'true' : 'false'}، provider={aiRuntimeStatus.image.provider}، model source={aiRuntimeStatus.image.modelSource || '-'}، admin model={aiRuntimeStatus.image.modelAdminValue}، runtime provider={aiRuntimeStatus.image.modelProviderName || '-'}، runtime model={aiRuntimeStatus.image.modelRuntimeValue}، operation={aiRuntimeStatus.image.operation || '-'}، host={aiRuntimeStatus.image.baseUrlHost || '-'}، key source={aiRuntimeStatus.image.apiKeySource}، fingerprint={aiRuntimeStatus.image.apiKeyFingerprint || '-'}
                  ، resolution={aiRuntimeStatus.image.resolution}، aspect={aiRuntimeStatus.image.aspectRatio}، output={aiRuntimeStatus.image.outputFormat}، safety={aiRuntimeStatus.image.safetyFilterLevel}، poll={aiRuntimeStatus.image.pollIntervalMs || '-'} / {aiRuntimeStatus.image.pollTimeoutMs || '-'}، maxMB={aiRuntimeStatus.image.maxDownloadMb || '-'}، edit={aiRuntimeStatus.image.editEnabled ? 'true' : 'false'}، validation={aiRuntimeStatus.image.lastValidationStatus || '-'}
                  ، storage={aiRuntimeStatus.image.storageDir || '-'}، writable={aiRuntimeStatus.image.storageWritable ? 'true' : 'false'}، serve={aiRuntimeStatus.image.publicServeRoute || '/api/images/serve/:taskId'}
                </p>
              ) : null}
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Model preset</span>
                  <select
                    value={String(siteSettings.settings['ai.image.model_preset'] ?? 'nano-banana')}
                    onChange={(e) => applyImagePreset(e.target.value)}
                  >
                    {imageModelPresets.map((preset) => (
                      <option key={preset.id} value={preset.id}>{preset.label}</option>
                    ))}
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Image provider</span>
                  <select
                    value={String(siteSettings.settings['ai.image.provider'] ?? 'metis')}
                    onChange={(e) => updateSiteSetting('ai.image.provider', e.target.value)}
                  >
                    {IMAGE_PROVIDER_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </label>
                <TextField
                  label="Image base URL"
                  value={String(siteSettings.settings['ai.image.base_url'] ?? 'https://api.metisai.ir')}
                  onChange={(e) => updateSiteSetting('ai.image.base_url', e.target.value)}
                />
                <TextField
                  label="Admin model value"
                  value={String(siteSettings.settings['ai.image.model.admin_value'] ?? siteSettings.settings['ai.image.model'] ?? 'gemini-2.5-flash-image')}
                  onChange={(e) => updateSiteSettingsPatch({ 'ai.image.model.admin_value': e.target.value, 'ai.image.model': e.target.value })}
                />
                <TextField
                  label="Runtime provider name"
                  value={String(siteSettings.settings['ai.image.model.runtime_provider_name'] ?? 'google')}
                  onChange={(e) => updateSiteSetting('ai.image.model.runtime_provider_name', e.target.value)}
                />
                <TextField
                  label="Runtime model"
                  value={String(siteSettings.settings['ai.image.model.runtime_model'] ?? 'nano-banana')}
                  onChange={(e) => updateSiteSetting('ai.image.model.runtime_model', e.target.value)}
                />
                <TextField
                  label="Operation"
                  value={String(siteSettings.settings['ai.image.operation'] ?? 'Imagine')}
                  onChange={(e) => updateSiteSetting('ai.image.operation', e.target.value)}
                />
                <label className="admin-select-field">
                  <span>رزولوشن تصویر</span>
                  <select
                    value={String(siteSettings.settings['ai.image.resolution'] ?? '1K')}
                    onChange={(e) => updateSiteSetting('ai.image.resolution', e.target.value)}
                  >
                    {IMAGE_RESOLUTION_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>نسبت تصویر</span>
                  <select
                    value={String(siteSettings.settings['ai.image.aspect_ratio'] ?? '1:1')}
                    onChange={(e) => updateSiteSetting('ai.image.aspect_ratio', e.target.value)}
                  >
                    {IMAGE_ASPECT_RATIO_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>فرمت خروجی</span>
                  <select
                    value={String(siteSettings.settings['ai.image.output_format'] ?? 'jpg')}
                    onChange={(e) => updateSiteSetting('ai.image.output_format', e.target.value)}
                  >
                    {IMAGE_OUTPUT_FORMAT_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Safety filter</span>
                  <select
                    value={String(siteSettings.settings['ai.image.safety_filter_level'] ?? 'block_only_high')}
                    onChange={(e) => updateSiteSetting('ai.image.safety_filter_level', e.target.value)}
                  >
                    {IMAGE_SAFETY_FILTER_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </label>
                <TextField
                  label="Max download MB"
                  type="number"
                  value={String(siteSettings.settings['ai.image.max_download_mb'] ?? 10)}
                  onChange={(e) => updateSiteSetting('ai.image.max_download_mb', Number(e.target.value))}
                />
              </FieldGroup>

              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Image generation</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Image edit</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.edit_enabled'] ?? false))}
                    onChange={(e) => updateSiteSetting('ai.image.edit_enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Prompt enhancer</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_enhancer_enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_enhancer_enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <TextField
                  label="Poll interval ms"
                  type="number"
                  value={String(siteSettings.settings['ai.image.poll_interval_ms'] ?? 2000)}
                  onChange={(e) => updateSiteSetting('ai.image.poll_interval_ms', Number(e.target.value))}
                />
                <TextField
                  label="Poll timeout ms"
                  type="number"
                  value={String(siteSettings.settings['ai.image.poll_timeout_ms'] ?? 120000)}
                  onChange={(e) => updateSiteSetting('ai.image.poll_timeout_ms', Number(e.target.value))}
                />
              </FieldGroup>
              <TextAreaField
                label="Default negative prompt"
                rows={2}
                value={String(siteSettings.settings['ai.image.default_negative_prompt'] ?? 'no humans, no unrelated objects, no text distortion, no watermark')}
                onChange={(e) => updateSiteSetting('ai.image.default_negative_prompt', e.target.value)}
              />
              <TextAreaField
                label="Custom args JSON"
                rows={4}
                value={String(siteSettings.settings['ai.image.custom_args_json'] ?? '{}')}
                onChange={(e) => updateSiteSetting('ai.image.custom_args_json', e.target.value)}
              />
              <h4>خواندن و تحلیل تصویر</h4>
              {aiRuntimeStatus?.vision ? (
                <p className="admin-note">
                  Runtime Vision: enabled={aiRuntimeStatus.vision.enabled ? 'true' : 'false'}، provider={aiRuntimeStatus.vision.provider}، mode={aiRuntimeStatus.vision.mode}، default={aiRuntimeStatus.vision.defaultModel}، fast={aiRuntimeStatus.vision.fastModel}، experimental={aiRuntimeStatus.vision.experimentalModel || '-'}، quality={aiRuntimeStatus.vision.qualityModel}، pro={aiRuntimeStatus.vision.proModel}، allowPro={aiRuntimeStatus.vision.allowProModel ? 'true' : 'false'}، key source={aiRuntimeStatus.vision.apiKeySource}، key={aiRuntimeStatus.vision.apiKeySet ? 'set' : 'missing'}، transport={aiRuntimeStatus.vision.transport}، timeout={aiRuntimeStatus.vision.timeoutMs}/{aiRuntimeStatus.vision.fallbackTimeoutMs}، maxTokens={aiRuntimeStatus.vision.maxOutputTokens}، simple={aiRuntimeStatus.vision.selectedModelForSimpleImage || '-'}، OCR/design={aiRuntimeStatus.vision.selectedModelForOcrOrDesign || '-'}، validation={aiRuntimeStatus.vision.lastValidationStatus || '-'}
                </p>
              ) : null}
              <p className="admin-note">
                production = gemini-2.5-flash، experimental/economy = gemini-2.5-flash-lite-preview فقط اگر health سالم باشد، دقیق = gemini-2.5-flash، Pro فقط با فعال‌سازی دستی.
              </p>
              {normalizeVisionModeForPanel(siteSettings.settings['ai.vision.mode']) === 'pro' && !Boolean(siteSettings.settings['ai.vision.allow_pro_model'] ?? false) ? (
                <InlineMessage text="Mode روی Pro است اما allow_pro_model غیرفعال است؛ runtime به gemini-2.5-flash برمی‌گردد." variant="help" />
              ) : null}
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Vision</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.vision.enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.vision.enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Provider</span>
                  <select
                    value={String(siteSettings.settings['ai.vision.provider'] ?? 'metis-gemini')}
                    onChange={(e) => updateSiteSetting('ai.vision.provider', e.target.value)}
                  >
                    <option value="metis-gemini">metis-gemini</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Mode</span>
                  <select
                    value={normalizeVisionModeForPanel(siteSettings.settings['ai.vision.mode'])}
                    onChange={(e) => updateSiteSetting('ai.vision.mode', e.target.value)}
                  >
                    {VISION_MODE_OPTIONS.map((option) => (
                      <option key={option} value={option}>
                        {option === 'economy' ? 'اقتصادی' : option === 'balanced' ? 'متعادل' : option === 'accurate' ? 'دقیق' : 'Pro'}
                      </option>
                    ))}
                  </select>
                </label>
                <TextField
                  label="Default model"
                  value={String(siteSettings.settings['ai.vision.default_model'] ?? siteSettings.settings['ai.vision.model'] ?? 'gemini-2.5-flash')}
                  onChange={(e) => updateSiteSettingsPatch({ 'ai.vision.default_model': e.target.value, 'ai.vision.model': e.target.value })}
                />
                <TextField
                  label="Fast model"
                  value={String(siteSettings.settings['ai.vision.fast_model'] ?? 'gemini-2.5-flash')}
                  onChange={(e) => updateSiteSetting('ai.vision.fast_model', e.target.value)}
                />
                <TextField
                  label="Experimental model"
                  value={String(siteSettings.settings['ai.vision.experimental_model'] ?? 'gemini-2.5-flash-lite-preview')}
                  onChange={(e) => updateSiteSetting('ai.vision.experimental_model', e.target.value)}
                />
                <TextField
                  label="Quality model"
                  value={String(siteSettings.settings['ai.vision.quality_model'] ?? 'gemini-2.5-flash')}
                  onChange={(e) => updateSiteSetting('ai.vision.quality_model', e.target.value)}
                />
                <TextField
                  label="Pro model"
                  value={String(siteSettings.settings['ai.vision.pro_model'] ?? 'gemini-2.5-pro')}
                  onChange={(e) => updateSiteSetting('ai.vision.pro_model', e.target.value)}
                />
                <label className="admin-select-field">
                  <span>Transport</span>
                  <select
                    value={String(siteSettings.settings['ai.vision.transport'] ?? 'auto')}
                    onChange={(e) => updateSiteSetting('ai.vision.transport', e.target.value)}
                  >
                    {VISION_TRANSPORT_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Media resolution</span>
                  <select
                    value={String(siteSettings.settings['ai.vision.media_resolution'] ?? 'auto')}
                    onChange={(e) => updateSiteSetting('ai.vision.media_resolution', e.target.value)}
                  >
                    {VISION_MEDIA_RESOLUTION_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
              </FieldGroup>
              <FieldGroup direction="row">
                <TextField
                  label="Vision base URL"
                  value={String(siteSettings.settings['ai.vision.base_url'] ?? 'https://api.metisai.ir')}
                  onChange={(e) => updateSiteSetting('ai.vision.base_url', e.target.value)}
                />
                <TextField
                  label="Timeout ms"
                  type="number"
                  value={String(siteSettings.settings['ai.vision.timeout_ms'] ?? 30000)}
                  onChange={(e) => updateSiteSetting('ai.vision.timeout_ms', Number(e.target.value))}
                />
                <TextField
                  label="Fallback timeout ms"
                  type="number"
                  value={String(siteSettings.settings['ai.vision.fallback_timeout_ms'] ?? 45000)}
                  onChange={(e) => updateSiteSetting('ai.vision.fallback_timeout_ms', Number(e.target.value))}
                />
                <TextField
                  label="Max image MB"
                  type="number"
                  value={String(siteSettings.settings['ai.vision.max_image_mb'] ?? 10)}
                  onChange={(e) => updateSiteSetting('ai.vision.max_image_mb', Number(e.target.value))}
                />
                <TextField
                  label="Temperature"
                  type="number"
                  step="0.1"
                  value={String(siteSettings.settings['ai.vision.temperature'] ?? 0.1)}
                  onChange={(e) => updateSiteSetting('ai.vision.temperature', Number(e.target.value))}
                />
                <TextField
                  label="Max output tokens"
                  type="number"
                  value={String(siteSettings.settings['ai.vision.max_output_tokens'] ?? 900)}
                  onChange={(e) => updateSiteSetting('ai.vision.max_output_tokens', Number(e.target.value))}
                />
                <label className="admin-select-field">
                  <span>Allow Pro model</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.vision.allow_pro_model'] ?? false))}
                    onChange={(e) => updateSiteSetting('ai.vision.allow_pro_model', e.target.value === 'true')}
                  >
                    <option value="false">غیرفعال</option>
                    <option value="true">فعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Chat key fallback</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.vision.allow_chat_key_fallback'] ?? false))}
                    onChange={(e) => updateSiteSetting('ai.vision.allow_chat_key_fallback', e.target.value === 'true')}
                  >
                    <option value="false">غیرفعال</option>
                    <option value="true">فعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Store metadata</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.vision.store_metadata'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.vision.store_metadata', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
              </FieldGroup>
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Model health</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.vision.model_health.enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.vision.model_health.enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <TextField
                  label="Health failure threshold"
                  type="number"
                  value={String(siteSettings.settings['ai.vision.model_health.failure_threshold'] ?? 3)}
                  onChange={(e) => updateSiteSetting('ai.vision.model_health.failure_threshold', Number(e.target.value))}
                />
                <TextField
                  label="Health cooldown minutes"
                  type="number"
                  value={String(siteSettings.settings['ai.vision.model_health.cooldown_minutes'] ?? 60)}
                  onChange={(e) => updateSiteSetting('ai.vision.model_health.cooldown_minutes', Number(e.target.value))}
                />
              </FieldGroup>
              {aiRuntimeStatus?.vision?.modelHealth ? (
                <pre className="admin-json-preview">{JSON.stringify(aiRuntimeStatus.vision.modelHealth, null, 2)}</pre>
              ) : null}
              <TextAreaField
                label="Vision system prompt"
                rows={7}
                value={String(siteSettings.settings['ai.vision.system_prompt'] ?? VISION_DEFAULT_SYSTEM_PROMPT)}
                onChange={(e) => updateSiteSetting('ai.vision.system_prompt', e.target.value)}
              />
              <TextAreaField
                label="OCR prompt"
                rows={3}
                value={String(siteSettings.settings['ai.vision.ocr_prompt'] ?? VISION_DEFAULT_OCR_PROMPT)}
                onChange={(e) => updateSiteSetting('ai.vision.ocr_prompt', e.target.value)}
              />
              <TextAreaField
                label="Design analysis prompt"
                rows={3}
                value={String(siteSettings.settings['ai.vision.design_analysis_prompt'] ?? VISION_DEFAULT_DESIGN_PROMPT)}
                onChange={(e) => updateSiteSetting('ai.vision.design_analysis_prompt', e.target.value)}
              />
              <FieldGroup direction="row">
                <TextField
                  label="Prompt تست Vision"
                  value={visionTestPrompt}
                  onChange={(e) => setVisionTestPrompt(e.target.value)}
                />
                <label className="admin-control-field">
                  <span>تصویر تست</span>
                  <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setVisionTestFile(e.target.files?.[0] || null)} />
                </label>
                <Button onClick={() => void runVisionDryRun()} disabled={visionTestLoading}>
                  تست Vision Dry-run
                </Button>
                <Button variant="secondary" onClick={() => void runVisionLiveTest()} disabled={visionTestLoading}>
                  تست Vision Live
                </Button>
                <Button variant="secondary" onClick={() => void runVisionModelProbe()} disabled={visionTestLoading}>
                  تست Model Probe
                </Button>
              </FieldGroup>
              {visionTestMessage ? (
                <InlineMessage text={visionTestMessage} variant={visionTestMessage.includes('موفقیت') ? 'success' : 'error'} />
              ) : null}
              {visionTestResult ? (
                <pre className="admin-json-preview">{JSON.stringify(visionTestResult, null, 2)}</pre>
              ) : null}
              <h4>بهینه‌ساز پرامپت تصویر</h4>
              {aiRuntimeStatus?.imagePromptRefiner ? (
                <div className="runtime-card">
                  <strong>Refiner API key</strong>
                  <span>{aiRuntimeStatus.imagePromptRefiner.apiKeySet ? 'تنظیم شده' : 'تنظیم نشده'}</span>
                  <small>{aiRuntimeStatus.imagePromptRefiner.apiKeySource}</small>
                </div>
              ) : null}
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Refiner</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Provider</span>
                  <select
                    value={String(siteSettings.settings['ai.image.prompt_refiner.provider'] ?? 'metis')}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.provider', e.target.value)}
                  >
                    <option value="metis">metis</option>
                  </select>
                </label>
                <TextField
                  label="Refiner model"
                  value={String(siteSettings.settings['ai.image.prompt_refiner.model'] ?? 'gemini-2.5-flash')}
                  onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.model', e.target.value)}
                />
                <TextField
                  label="Temperature"
                  type="number"
                  value={String(siteSettings.settings['ai.image.prompt_refiner.temperature'] ?? 0.2)}
                  onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.temperature', Number(e.target.value))}
                />
                <TextField
                  label="Max tokens"
                  type="number"
                  value={String(siteSettings.settings['ai.image.prompt_refiner.max_tokens'] ?? 700)}
                  onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.max_tokens', Number(e.target.value))}
                />
                <TextField
                  label="Timeout ms"
                  type="number"
                  value={String(siteSettings.settings['ai.image.prompt_refiner.timeout_ms'] ?? 6000)}
                  onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.timeout_ms', Number(e.target.value))}
                />
              </FieldGroup>
              <FieldGroup direction="row">
                <label className="admin-select-field">
                  <span>Fallback داخلی</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.fallback_enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.fallback_enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Cache</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.cache_enabled'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.cache_enabled', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <TextField
                  label="Cache TTL minutes"
                  type="number"
                  value={String(siteSettings.settings['ai.image.prompt_refiner.cache_ttl_minutes'] ?? 1440)}
                  onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.cache_ttl_minutes', Number(e.target.value))}
                />
                <label className="admin-select-field">
                  <span>حفظ متن فارسی</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.preserve_persian_text'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.preserve_persian_text', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Human guard</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.human_subject_guard'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.human_subject_guard', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Child guard</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.child_safety_guard'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.child_safety_guard', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Chat key fallback</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.allow_chat_key_fallback'] ?? false))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.allow_chat_key_fallback', e.target.value === 'true')}
                  >
                    <option value="false">غیرفعال</option>
                    <option value="true">فعال</option>
                  </select>
                </label>
                <label className="admin-select-field">
                  <span>Store metadata</span>
                  <select
                    value={String(Boolean(siteSettings.settings['ai.image.prompt_refiner.store_metadata'] ?? true))}
                    onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.store_metadata', e.target.value === 'true')}
                  >
                    <option value="true">فعال</option>
                    <option value="false">غیرفعال</option>
                  </select>
                </label>
              </FieldGroup>
              <TextAreaField
                label="Default style"
                rows={2}
                value={String(siteSettings.settings['ai.image.prompt_refiner.default_style'] ?? IMAGE_PROMPT_REFINER_DEFAULT_STYLE)}
                onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.default_style', e.target.value)}
              />
              <TextAreaField
                label="Refiner negative prompt"
                rows={2}
                value={String(siteSettings.settings['ai.image.prompt_refiner.default_negative_prompt'] ?? IMAGE_PROMPT_REFINER_DEFAULT_NEGATIVE)}
                onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.default_negative_prompt', e.target.value)}
              />
              <TextAreaField
                label="Refiner system prompt"
                rows={7}
                value={String(siteSettings.settings['ai.image.prompt_refiner.system_prompt'] ?? IMAGE_PROMPT_REFINER_DEFAULT_SYSTEM_PROMPT)}
                onChange={(e) => updateSiteSetting('ai.image.prompt_refiner.system_prompt', e.target.value)}
              />
              <FieldGroup direction="row">
                <TextField
                  label="Prompt تست بهینه‌ساز تصویر"
                  value={imageTestPrompt}
                  onChange={(e) => setImageTestPrompt(e.target.value)}
                />
                <Button onClick={() => void runImageDryRun()} disabled={imageTestLoading}>
                  تست refiner Dry-run
                </Button>
                <Button variant="secondary" onClick={() => void runImageLiveTest()} disabled={imageTestLoading}>
                  تست تصویر Live
                </Button>
              </FieldGroup>
              {imageTestMessage ? (
                <InlineMessage text={imageTestMessage} variant={imageTestMessage.includes('موفقیت') ? 'success' : 'error'} />
              ) : null}
              {imageTestResult ? (
                <pre className="admin-json-preview">{JSON.stringify(imageTestResult, null, 2)}</pre>
              ) : null}

              <h4>ورود و ثبت‌نام</h4>
              <FieldGroup direction="row">
                <TextField
                  label="اعتبار OTP (ثانیه)"
                  type="number"
                  value={String(siteSettings.settings['auth.otp.expire_seconds'] ?? 120)}
                  onChange={(e) => updateSiteSetting('auth.otp.expire_seconds', Number(e.target.value))}
                />
                <TextField
                  label="فاصله ارسال مجدد OTP (ms)"
                  type="number"
                  value={String(siteSettings.settings['auth.otp.resend_cooldown_ms'] ?? 60000)}
                  onChange={(e) => updateSiteSetting('auth.otp.resend_cooldown_ms', Number(e.target.value))}
                />
              </FieldGroup>
              <FieldGroup direction="row">
                <TextField
                  label="حداقل سن"
                  type="number"
                  value={String(siteSettings.settings['auth.validation.age_min'] ?? 8)}
                  onChange={(e) => updateSiteSetting('auth.validation.age_min', Number(e.target.value))}
                />
                <TextField
                  label="حداکثر سن"
                  type="number"
                  value={String(siteSettings.settings['auth.validation.age_max'] ?? 18)}
                  onChange={(e) => updateSiteSetting('auth.validation.age_max', Number(e.target.value))}
                />
              </FieldGroup>

              <FieldGroup direction="row" className="config-actions">
                <Button onClick={() => void saveSiteSettings()} disabled={siteSettingsSaving}>
                  {siteSettingsSaving ? 'در حال ذخیره...' : 'ذخیره تنظیمات سایت'}
                </Button>
              </FieldGroup>
            </>
          ) : (
            <InlineMessage text="در حال بارگذاری تنظیمات سایت..." variant="help" />
          )}
        </div>
      ) : null}

      {tab === 'supervisedOtp' ? supervisedOtpCard : null}

      {tab === 'errors' ? (
        <div className="admin-table-wrap">
        <table className="admin-table">
          <thead><tr><th>نوع</th><th>Endpoint</th><th>Status</th><th>پیام</th><th>زمان</th></tr></thead>
          <tbody>
            {errors.map((item, index) => (
              <tr key={index}><td>{item.error_type}</td><td>{item.endpoint}</td><td>{item.status_code}</td><td>{item.details}</td><td>{item.created_at}</td></tr>
            ))}
          </tbody>
        </table>
        </div>
      ) : null}

      {tab === 'config' && config ? (
        <div className="admin-section config-panel">
          <h3>پیکربندی سیستم</h3>
          <p className="admin-note">تنظیمات کلی مدل و ویژگی های تجربه کاربری را از این بخش مدیریت کنید.</p>
          <FieldGroup direction="row">
            <TextField
              label="Model"
              value={config.model || ''}
              onChange={(e) => setConfig({ ...config, model: e.target.value })}
              helperText="نام مدل مورد استفاده در پاسخ دهی دستیار"
            />
            <TextField
              label="Timeout (ms)"
              type="number"
              value={String(config.timeoutMs || 30000)}
              onChange={(e) => setConfig({ ...config, timeoutMs: Number(e.target.value) })}
              helperText="حداکثر زمان انتظار برای هر درخواست"
            />
          </FieldGroup>
          <h4>ویژگی ها</h4>
          <FieldGroup direction="row" className="config-flags">
            <label><input type="checkbox" checked={Boolean(config.features?.voiceInput)} onChange={(e) => setConfig({ ...config, features: { ...config.features, voiceInput: e.target.checked } })} /> voiceInput</label>
            <label><input type="checkbox" checked={Boolean(config.features?.quickChips)} onChange={(e) => setConfig({ ...config, features: { ...config.features, quickChips: e.target.checked } })} /> quickChips</label>
            <label><input type="checkbox" checked={Boolean(config.features?.practiceMode)} onChange={(e) => setConfig({ ...config, features: { ...config.features, practiceMode: e.target.checked } })} /> practiceMode</label>
          </FieldGroup>
          <FieldGroup direction="row" className="config-actions">
            <Button onClick={() => void saveConfig()} disabled={configSaving}>
              {configSaving ? 'در حال ذخیره...' : 'ذخیره'}
            </Button>
            {configMessage ? <InlineMessage text={configMessage} variant={configMessage.includes('موفقیت') ? 'success' : 'error'} /> : null}
          </FieldGroup>

          <div className="system-prompt-box">
            <h4>سیستم پرامپت (System Prompt)</h4>
            <p className="admin-note">متن دستور پایه مدل در این بخش مدیریت می شود و بدون ری استارت سرور اعمال خواهد شد.</p>
            {systemPromptLoading ? <InlineMessage text="در حال بارگذاری پرامپت..." variant="help" /> : null}
            <TextAreaField
              className="system-prompt-textarea"
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              placeholder="متن سیستم پرامپت را وارد کنید"
              rows={14}
              aria-label="سیستم پرامپت"
            />
            <FieldGroup direction="row" className="config-actions">
              <Button onClick={() => void saveSystemPrompt()} disabled={systemPromptSaving || systemPromptLoading}>
                {systemPromptSaving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
              </Button>
              {systemPromptMessage ? (
                <InlineMessage text={systemPromptMessage} variant={systemPromptMessage.includes('موفقیت') ? 'success' : 'error'} />
              ) : null}
            </FieldGroup>
          </div>
        </div>
      ) : null}

      {tab === 'audit' ? (
        <div className="admin-table-wrap">
        <table className="admin-table">
          <thead><tr><th>زمان</th><th>ادمین</th><th>عملیات</th><th>هدف</th><th>جزئیات</th></tr></thead>
          <tbody>
            {logs.map((item, index) => (
              <tr key={index}><td>{item.timestamp}</td><td>{item.adminUsername}</td><td>{item.action}</td><td>{item.target}</td><td>{JSON.stringify(item.details)}</td></tr>
            ))}
          </tbody>
        </table>
        </div>
      ) : null}

      <div className="admin-section admin-report">
        <h3>Export Report</h3>
        <FieldGroup direction="row" className="admin-report-options">
          <label className="admin-select-field">
            <span>فرمت خروجی</span>
            <select value={reportFormat} onChange={(e) => setReportFormat(e.target.value as ReportFormat)}>
              <option value="csv">CSV</option>
              <option value="txt">TXT</option>
            </select>
          </label>
          <label className="admin-select-field">
            <span>بازه زمانی</span>
            <select value={reportRangePreset} onChange={(e) => setReportRangePreset(e.target.value as ReportRangePreset)}>
              <option value="today">امروز</option>
              <option value="7d">۷ روز اخیر</option>
              <option value="30d">۳۰ روز اخیر</option>
              <option value="custom">بازه دلخواه</option>
            </select>
          </label>
        </FieldGroup>
        {reportRangePreset === 'custom' ? (
          <FieldGroup direction="row" className="admin-report-options">
            <label className="admin-control-field">
              <span>از تاریخ</span>
              <input type="date" value={reportCustomFromDate} onChange={(e) => setReportCustomFromDate(e.target.value)} />
            </label>
            <label className="admin-control-field">
              <span>تا تاریخ</span>
              <input type="date" value={reportCustomToDate} onChange={(e) => setReportCustomToDate(e.target.value)} />
            </label>
          </FieldGroup>
        ) : null}
        <p className="admin-note">TXT برای تحلیل با AI خواناتر است و پیام کاربر و پاسخ AI را به صورت turn کنار هم می‌آورد.</p>
        <FieldGroup direction="row" className="admin-report-options">
          {REPORT_SECTION_OPTIONS.map((section) => (
            <label key={section.key}>
              <input
                type="checkbox"
                checked={reportOptions[section.key]}
                onChange={(e) => toggleReportSection(section.key, e.target.checked)}
              /> {section.label}
            </label>
          ))}
        </FieldGroup>
        <FieldGroup direction="row" className="admin-report-options">
          <label>
            <input
              type="checkbox"
              checked={reportGuestOnly}
              onChange={(e) => setReportGuestOnly(e.target.checked)}
            /> فقط مهمان‌ها
          </label>
          <label className="admin-control-field">
            <span>حداقل تعداد پیام</span>
            <input
              type="number"
              min="0"
              value={reportMinGuestMessages}
              onChange={(e) => setReportMinGuestMessages(e.target.value)}
            />
          </label>
          <label>
            <input
              type="checkbox"
              checked={reportGuestErrorsOnly}
              onChange={(e) => setReportGuestErrorsOnly(e.target.checked)}
            /> فقط گفتگوهای دارای خطا
          </label>
          <label>
            <input
              type="checkbox"
              checked={reportAmbiguousOnly}
              onChange={(e) => setReportAmbiguousOnly(e.target.checked)}
            /> فقط پیام‌های کوتاه مبهم
          </label>
        </FieldGroup>
        <FieldGroup direction="row" className="admin-report-options">
          <label>
            <input
              type="radio"
              name="report-user-scope"
              checked={reportUserScope === 'all'}
              onChange={() => setReportUserScope('all')}
            /> همه کاربران
          </label>
          <label>
            <input
              type="radio"
              name="report-user-scope"
              checked={reportUserScope === 'selected'}
              onChange={() => setReportUserScope('selected')}
            /> فقط کاربران انتخاب‌شده ({selectedReportUserIds.length})
          </label>
          <Button variant="ghost" size="sm" disabled={selectedReportUserIds.length === 0} onClick={() => setSelectedReportUserIds([])}>
            پاک کردن انتخاب‌ها
          </Button>
        </FieldGroup>
        <FieldGroup direction="row" className="admin-report-actions">
          <Button variant="secondary" onClick={downloadReport} disabled={reportUserScope === 'selected' && selectedReportUserIds.length === 0}>دانلود گزارش</Button>
        </FieldGroup>
      </div>
    </div>
  );
}

export default AdminPanel;
