const { DEFAULT_REFINER_SYSTEM_PROMPT } = require('../image-generation/image-prompt-refiner.service');

const SETTING_DEFINITIONS = {
  'guest.message_limit': {
    label: 'تعداد پیام مهمان',
    type: 'number',
    category: 'guest',
    defaultValue: 10,
    min: 0,
    adminEditable: true
  },
  'guest.image_limit_daily': {
    label: 'سقف ساخت تصویر مهمان در روز',
    type: 'number',
    category: 'guest',
    defaultValue: 0,
    nullable: true,
    min: 0,
    adminEditable: true
  },
  'guest.image_limit_hourly': {
    label: 'سقف ساخت تصویر مهمان در ساعت',
    type: 'number',
    category: 'guest',
    defaultValue: 0,
    nullable: true,
    min: 0,
    adminEditable: true
  },
  'guest.limit_modal.title': {
    label: 'عنوان مودال محدودیت مهمان',
    type: 'string',
    category: 'guest',
    defaultValue: 'برای ادامه ثبت‌نام کن',
    adminEditable: true
  },
  'guest.limit_modal.heading': {
    label: 'تیتر مودال محدودیت مهمان',
    type: 'string',
    category: 'guest',
    defaultValue: 'برای ادامه‌ی گفتگو، لطفاً ثبت‌نام کن!',
    adminEditable: true
  },
  'guest.limit_modal.body': {
    label: 'متن مودال محدودیت مهمان',
    type: 'string',
    category: 'guest',
    defaultValue: 'گفتگوی مهمان به سقف پیام‌ها رسیده و ادامه چت فقط با حساب کاربری انجام می‌شود.',
    adminEditable: true
  },
  'guest.limit_modal.badge_text': {
    label: 'نشان مودال محدودیت مهمان',
    type: 'string',
    category: 'guest',
    defaultValue: '۱۰',
    adminEditable: true
  },
  'guest.limit_modal.cta': {
    label: 'دکمه مودال محدودیت مهمان',
    type: 'string',
    category: 'guest',
    defaultValue: 'ثبت‌نام',
    adminEditable: true
  },
  'upload.image.max_size_mb': {
    label: 'حداکثر حجم عکس (MB)',
    type: 'number',
    category: 'upload',
    defaultValue: 5,
    min: 1,
    max: 50,
    adminEditable: true
  },
  'upload.image.max_files': {
    label: 'حداکثر تعداد عکس',
    type: 'number',
    category: 'upload',
    defaultValue: 5,
    min: 1,
    max: 20,
    adminEditable: true
  },
  'upload.image.allowed_types': {
    label: 'فرمت‌های مجاز عکس',
    type: 'stringArray',
    category: 'upload',
    defaultValue: ['image/jpeg', 'image/png', 'image/webp'],
    allowedValues: ['image/jpeg', 'image/png', 'image/webp'],
    adminEditable: true
  },
  'ai.chat.model': {
    label: 'مدل چت',
    type: 'string',
    category: 'ai',
    defaultValue: 'gemini-2.5-flash',
    adminEditable: true
  },
  'ai.image.model': {
    label: 'مدل ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'gemini-2.5-flash-image',
    nullable: true,
    adminEditable: true
  },
  'ai.image.enabled': {
    label: 'فعال بودن ساخت تصویر',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.model_preset': {
    label: 'Preset مدل ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'nano-banana',
    allowedValues: ['nano-banana-pro', 'nano-banana', 'flux-schnell', 'custom'],
    adminEditable: true
  },
  'ai.image.model.admin_value': {
    label: 'Admin model ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'gemini-2.5-flash-image',
    adminEditable: true
  },
  'ai.image.model.runtime_provider_name': {
    label: 'Runtime provider name ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'google',
    adminEditable: true
  },
  'ai.image.model.runtime_model': {
    label: 'Runtime model ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'nano-banana',
    adminEditable: true
  },
  'ai.image.operation': {
    label: 'Operation ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'Imagine',
    adminEditable: true
  },
  'ai.image.provider': {
    label: 'Provider ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'metis',
    allowedValues: ['metis', 'gemini', 'xai'],
    adminEditable: true
  },
  'ai.image.base_url': {
    label: 'Base URL ساخت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'https://api.metisai.ir',
    adminEditable: true
  },
  'ai.image.resolution': {
    label: 'رزولوشن تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: '1K',
    allowedValues: ['1K', '2K'],
    adminEditable: true
  },
  'ai.image.aspect_ratio': {
    label: 'نسبت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: '1:1',
    allowedValues: ['1:1', '2:3', '3:2', '3:4', '4:3', '4:5', '5:4', '9:16', '16:9', '21:9'],
    adminEditable: true
  },
  'ai.image.output_format': {
    label: 'فرمت خروجی تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'jpg',
    allowedValues: ['jpg', 'png'],
    adminEditable: true
  },
  'ai.image.safety_filter_level': {
    label: 'سطح safety filter تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'block_only_high',
    allowedValues: ['block_only_high', 'block_medium_and_above', 'block_low_and_above', 'block_none'],
    adminEditable: true
  },
  'ai.image.prompt_enhancer_enabled': {
    label: 'فعال بودن prompt enhancer تصویر',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.default_negative_prompt': {
    label: 'Negative prompt پیش‌فرض تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'no humans, no unrelated objects, no text distortion, no watermark',
    adminEditable: true
  },
  'ai.image.poll_interval_ms': {
    label: 'Image poll interval (ms)',
    type: 'number',
    category: 'ai',
    defaultValue: 2000,
    min: 500,
    max: 10000,
    adminEditable: true
  },
  'ai.image.poll_timeout_ms': {
    label: 'Image poll timeout (ms)',
    type: 'number',
    category: 'ai',
    defaultValue: 120000,
    min: 10000,
    max: 300000,
    adminEditable: true
  },
  'ai.image.max_download_mb': {
    label: 'حداکثر حجم دانلود تصویر (MB)',
    type: 'number',
    category: 'ai',
    defaultValue: 10,
    min: 1,
    max: 25,
    adminEditable: true
  },
  'ai.image.edit_enabled': {
    label: 'فعال بودن image edit',
    type: 'boolean',
    category: 'ai',
    defaultValue: false,
    adminEditable: true
  },
  'ai.image.custom_args_json': {
    label: 'Custom args JSON تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: '{}',
    adminEditable: true
  },
  'ai.image.prompt_refiner.enabled': {
    label: 'فعال بودن بهینه‌ساز پرامپت تصویر',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.prompt_refiner.provider': {
    label: 'Provider بهینه‌ساز پرامپت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'metis',
    allowedValues: ['metis'],
    adminEditable: true
  },
  'ai.image.prompt_refiner.model': {
    label: 'مدل بهینه‌ساز پرامپت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'gemini-2.5-flash',
    adminEditable: true
  },
  'ai.image.prompt_refiner.temperature': {
    label: 'Temperature بهینه‌ساز پرامپت تصویر',
    type: 'number',
    category: 'ai',
    defaultValue: 0.2,
    min: 0,
    max: 2,
    adminEditable: true
  },
  'ai.image.prompt_refiner.max_tokens': {
    label: 'Max tokens بهینه‌ساز پرامپت تصویر',
    type: 'number',
    category: 'ai',
    defaultValue: 700,
    min: 100,
    max: 2000,
    adminEditable: true
  },
  'ai.image.prompt_refiner.timeout_ms': {
    label: 'Timeout بهینه‌ساز پرامپت تصویر (ms)',
    type: 'number',
    category: 'ai',
    defaultValue: 6000,
    min: 1000,
    max: 30000,
    adminEditable: true
  },
  'ai.image.prompt_refiner.fallback_enabled': {
    label: 'Fallback داخلی بهینه‌ساز پرامپت تصویر',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.prompt_refiner.cache_enabled': {
    label: 'Cache بهینه‌ساز پرامپت تصویر',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.prompt_refiner.cache_ttl_minutes': {
    label: 'TTL cache بهینه‌ساز پرامپت تصویر (minutes)',
    type: 'number',
    category: 'ai',
    defaultValue: 1440,
    min: 1,
    max: 10080,
    adminEditable: true
  },
  'ai.image.prompt_refiner.preserve_persian_text': {
    label: 'حفظ متن فارسی داخل تصویر',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.prompt_refiner.human_subject_guard': {
    label: 'Guard سوژه انسانی',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.prompt_refiner.child_safety_guard': {
    label: 'Guard ایمنی کودک',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.prompt_refiner.default_style': {
    label: 'Style پیش‌فرض بهینه‌ساز پرامپت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'clean, colorful, child-friendly digital illustration, soft lighting, high quality',
    adminEditable: true
  },
  'ai.image.prompt_refiner.default_negative_prompt': {
    label: 'Negative prompt پیش‌فرض بهینه‌ساز پرامپت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: 'no watermark, no distorted text, no extra fingers, no blurry face, no unrelated objects',
    adminEditable: true
  },
  'ai.image.prompt_refiner.system_prompt': {
    label: 'System prompt بهینه‌ساز پرامپت تصویر',
    type: 'string',
    category: 'ai',
    defaultValue: DEFAULT_REFINER_SYSTEM_PROMPT,
    adminEditable: true
  },
  'ai.image.prompt_refiner.store_metadata': {
    label: 'ذخیره metadata بهینه‌ساز پرامپت تصویر',
    type: 'boolean',
    category: 'ai',
    defaultValue: true,
    adminEditable: true
  },
  'ai.image.prompt_refiner.allow_chat_key_fallback': {
    label: 'اجازه fallback به METIS_CHAT_API_KEY',
    type: 'boolean',
    category: 'ai',
    defaultValue: false,
    adminEditable: true
  },
  'ai.chat.temperature': {
    label: 'Temperature چت',
    type: 'number',
    category: 'ai',
    defaultValue: 0.6,
    min: 0,
    max: 2,
    adminEditable: true
  },
  'ai.chat.timeout_ms': {
    label: 'Timeout چت (ms)',
    type: 'number',
    category: 'ai',
    defaultValue: 30000,
    min: 1000,
    max: 300000,
    adminEditable: true
  },
  'auth.otp.expire_seconds': {
    label: 'زمان اعتبار کد OTP (ثانیه)',
    type: 'number',
    category: 'auth',
    defaultValue: 120,
    min: 30,
    max: 3600,
    adminEditable: true
  },
  'auth.otp.resend_cooldown_ms': {
    label: 'فاصله ارسال مجدد OTP (ms)',
    type: 'number',
    category: 'auth',
    defaultValue: 60000,
    min: 10000,
    max: 3600000,
    adminEditable: true
  },
  'auth.validation.age_min': {
    label: 'حداقل سن ثبت‌نام',
    type: 'number',
    category: 'auth',
    defaultValue: 8,
    min: 0,
    max: 120,
    adminEditable: true
  },
  'auth.validation.age_max': {
    label: 'حداکثر سن ثبت‌نام',
    type: 'number',
    category: 'auth',
    defaultValue: 18,
    min: 0,
    max: 120,
    adminEditable: true
  }
};

const DEFAULT_SETTINGS = Object.fromEntries(
  Object.entries(SETTING_DEFINITIONS).map(([key, definition]) => [key, definition.defaultValue])
);

const normalizeStringArray = (value) => {
  if (Array.isArray(value)) {
    return value.map((item) => String(item || '').trim()).filter(Boolean);
  }
  if (typeof value === 'string') {
    return value.split(',').map((item) => item.trim()).filter(Boolean);
  }
  return [];
};

const coerceSettingValue = (key, value) => {
  const definition = SETTING_DEFINITIONS[key];
  if (!definition) {
    throw new Error(`Unknown setting: ${key}`);
  }

  if (definition.type === 'number') {
    if (definition.nullable && (value === null || value === undefined || value === '')) {
      return null;
    }
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) {
      throw new Error(`${key} must be a number`);
    }
    if (Number.isFinite(definition.min) && numeric < definition.min) {
      throw new Error(`${key} must be greater than or equal to ${definition.min}`);
    }
    if (Number.isFinite(definition.max) && numeric > definition.max) {
      throw new Error(`${key} must be less than or equal to ${definition.max}`);
    }
    return numeric;
  }

  if (definition.type === 'boolean') {
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') return value !== 0;
    if (typeof value === 'string') {
      const normalized = value.trim().toLowerCase();
      if (['true', '1', 'yes', 'on'].includes(normalized)) return true;
      if (['false', '0', 'no', 'off'].includes(normalized)) return false;
    }
    return Boolean(value);
  }

  if (definition.type === 'stringArray') {
    const items = normalizeStringArray(value);
    if (items.length === 0) {
      throw new Error(`${key} cannot be empty`);
    }
    if (Array.isArray(definition.allowedValues)) {
      const invalid = items.find((item) => !definition.allowedValues.includes(item));
      if (invalid) {
        throw new Error(`${key} contains an unsupported value: ${invalid}`);
      }
    }
    return [...new Set(items)];
  }

  if (definition.nullable && (value === null || value === undefined || value === '')) {
    return null;
  }

  const text = typeof value === 'string' ? value.trim() : String(value ?? '').trim();
  if (!text) {
    throw new Error(`${key} cannot be empty`);
  }
  if (Array.isArray(definition.allowedValues) && !definition.allowedValues.includes(text)) {
    throw new Error(`${key} contains an unsupported value: ${text}`);
  }
  return text;
};

const getDefaultSetting = (key) => {
  const definition = SETTING_DEFINITIONS[key];
  return definition ? definition.defaultValue : undefined;
};

module.exports = {
  SETTING_DEFINITIONS,
  DEFAULT_SETTINGS,
  coerceSettingValue,
  getDefaultSetting
};
