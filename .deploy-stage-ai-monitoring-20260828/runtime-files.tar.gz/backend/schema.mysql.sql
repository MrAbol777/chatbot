-- MySQL schema for Danoa backend
-- Recommended: create a dedicated database (not `mysql` system DB)
-- Example:
--   CREATE DATABASE IF NOT EXISTS danoaa_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
--   USE danoaa_app;

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS app_users (
  user_id VARCHAR(191) PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  age INT NOT NULL DEFAULT 0,
  phone VARCHAR(32) NULL,
  is_banned TINYINT(1) NOT NULL DEFAULT 0,
  registered_at DATETIME NOT NULL,
  last_active DATETIME NULL,
  INDEX idx_app_users_phone (phone),
  INDEX idx_app_users_last_active (last_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_guardians (
  guardian_id VARCHAR(191) PRIMARY KEY,
  phone VARCHAR(32) NOT NULL,
  display_name VARCHAR(191) NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_app_guardians_phone (phone),
  INDEX idx_app_guardians_updated_at (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_children (
  child_id VARCHAR(191) PRIMARY KEY,
  guardian_id VARCHAR(191) NOT NULL,
  name VARCHAR(191) NOT NULL,
  age INT NOT NULL DEFAULT 0,
  avatar VARCHAR(255) NULL,
  grade VARCHAR(64) NULL,
  safety_level VARCHAR(32) NOT NULL DEFAULT 'standard',
  guardian_consent_at DATETIME NULL,
  guardian_consent_version VARCHAR(32) NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  INDEX idx_app_children_guardian_id (guardian_id),
  INDEX idx_app_children_updated_at (updated_at),
  CONSTRAINT fk_app_children_user
    FOREIGN KEY (child_id)
    REFERENCES app_users(user_id)
    ON DELETE CASCADE,
  CONSTRAINT fk_app_children_guardian
    FOREIGN KEY (guardian_id)
    REFERENCES app_guardians(guardian_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_viana_oauth_flows (
  state_hash CHAR(64) PRIMARY KEY,
  browser_binding_hash CHAR(64) NOT NULL,
  code_verifier VARCHAR(128) NOT NULL,
  environment_key VARCHAR(32) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  expires_at DATETIME(6) NOT NULL,
  INDEX idx_viana_oauth_flows_expires (expires_at),
  INDEX idx_viana_oauth_flows_binding (browser_binding_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_viana_identities (
  identity_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  provider VARCHAR(32) NOT NULL,
  environment_key VARCHAR(32) NOT NULL,
  client_id VARCHAR(191) NOT NULL,
  subject VARCHAR(191) NOT NULL,
  user_id VARCHAR(191) NOT NULL,
  first_name VARCHAR(191) NOT NULL,
  last_name VARCHAR(191) NOT NULL,
  date_of_birth DATE NOT NULL,
  grade VARCHAR(64) NULL,
  gender ENUM('MALE','FEMALE') NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  last_login_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_viana_identity_provider_client_subject (provider, client_id, subject),
  INDEX idx_viana_identity_user (user_id),
  CONSTRAINT fk_viana_identity_user FOREIGN KEY (user_id)
    REFERENCES app_users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_auth_sessions (
  session_hash CHAR(64) PRIMARY KEY,
  csrf_token_hash CHAR(64) NOT NULL,
  user_id VARCHAR(191) NOT NULL,
  provider VARCHAR(32) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  last_activity_at DATETIME(6) NOT NULL,
  absolute_expires_at DATETIME(6) NOT NULL,
  INDEX idx_auth_sessions_user (user_id),
  INDEX idx_auth_sessions_expiry (absolute_expires_at),
  INDEX idx_auth_sessions_activity (last_activity_at),
  CONSTRAINT fk_auth_sessions_user FOREIGN KEY (user_id)
    REFERENCES app_users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(191) NOT NULL,
  event_type VARCHAR(100) NOT NULL,
  category VARCHAR(100) NULL,
  metadata JSON NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_app_events_user_id (user_id),
  INDEX idx_app_events_type (event_type),
  INDEX idx_app_events_created_at (created_at),
  CONSTRAINT fk_app_events_user
    FOREIGN KEY (user_id)
    REFERENCES app_users(user_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_app_errors (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  error_type VARCHAR(100) NOT NULL,
  endpoint VARCHAR(255) NULL,
  status_code INT NULL,
  details TEXT NOT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_app_errors_type (error_type),
  INDEX idx_app_errors_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_request_metrics (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  request_id VARCHAR(64) NOT NULL,
  method VARCHAR(12) NOT NULL,
  route VARCHAR(191) NOT NULL,
  status_code SMALLINT UNSIGNED NOT NULL,
  duration_ms INT UNSIGNED NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  INDEX idx_request_metrics_created (created_at),
  INDEX idx_request_metrics_route_created (route, created_at),
  INDEX idx_request_metrics_status_created (status_code, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_conversations (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(191) NOT NULL,
  conversation_id VARCHAR(191) NOT NULL,
  title VARCHAR(255) NULL,
  generated_title VARCHAR(255) NULL,
  title_source ENUM('default','generated','manual') NOT NULL DEFAULT 'default',
  title_generation_status ENUM('pending','generating','completed','fallback','failed') NULL DEFAULT NULL,
  title_model VARCHAR(191) NULL,
  title_generator_version VARCHAR(32) NULL,
  title_generation_latency_ms INT NULL,
  title_generated_at DATETIME NULL,
  title_manually_updated_at DATETIME NULL,
  pinned TINYINT(1) NOT NULL DEFAULT 0,
  messages JSON NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_app_conversations_user_conversation (user_id, conversation_id),
  INDEX idx_app_conversations_user_id (user_id),
  INDEX idx_app_conversations_updated_at (updated_at),
  INDEX idx_app_conversations_title_generation (title_generation_status, updated_at),
  CONSTRAINT fk_app_conversations_user
    FOREIGN KEY (user_id)
    REFERENCES app_users(user_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_chat_messages (
  message_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(191) NOT NULL,
  user_type VARCHAR(32) NOT NULL DEFAULT 'registered',
  conversation_id VARCHAR(191) NOT NULL,
  turn_id VARCHAR(64) NULL,
  role ENUM('user', 'assistant') NOT NULL,
  content MEDIUMTEXT NOT NULL,
  model VARCHAR(191) NULL,
  response_time_ms INT NULL,
  token_usage JSON NULL,
  error_code VARCHAR(100) NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_chat_messages_user_id (user_id),
  INDEX idx_chat_messages_conversation (conversation_id),
  INDEX idx_chat_messages_created_at (created_at),
  INDEX idx_chat_messages_role (role),
  UNIQUE KEY uq_chat_messages_turn_role (turn_id, role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_chat_turns (
  turn_id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(191) NOT NULL,
  conversation_id VARCHAR(191) NOT NULL,
  client_message_id VARCHAR(191) NULL,
  user_message MEDIUMTEXT NOT NULL,
  intent VARCHAR(32) NOT NULL,
  status ENUM('streaming', 'completed', 'cancelled', 'failed') NOT NULL DEFAULT 'streaming',
  reply MEDIUMTEXT NULL,
  model VARCHAR(191) NULL,
  token_usage JSON NULL,
  error_code VARCHAR(100) NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  completed_at DATETIME NULL,
  INDEX idx_chat_turns_user_conversation (user_id, conversation_id),
  INDEX idx_chat_turns_status (status),
  INDEX idx_chat_turns_updated_at (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_chat_attempts (
  attempt_id VARCHAR(64) PRIMARY KEY,
  turn_id VARCHAR(64) NOT NULL,
  status ENUM('streaming', 'completed', 'cancelled', 'failed') NOT NULL DEFAULT 'streaming',
  error_code VARCHAR(100) NULL,
  started_at DATETIME NOT NULL,
  finished_at DATETIME NULL,
  updated_at DATETIME NOT NULL,
  INDEX idx_chat_attempts_turn_id (turn_id),
  INDEX idx_chat_attempts_status (status),
  CONSTRAINT fk_chat_attempts_turn FOREIGN KEY (turn_id) REFERENCES app_chat_turns(turn_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS image_generations (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(191) NOT NULL,
  task_id VARCHAR(255) NOT NULL UNIQUE,
  prompt TEXT NOT NULL,
  original_prompt TEXT NULL,
  refined_prompt TEXT NULL,
  aspect_ratio VARCHAR(16) NOT NULL DEFAULT '1:1',
  operation ENUM('generate', 'edit') NOT NULL DEFAULT 'generate',
  conversation_id VARCHAR(191) NULL,
  parent_image_id BIGINT NULL,
  idempotency_key VARCHAR(191) NULL,
  status ENUM('QUEUE', 'WAITING', 'RUNNING', 'COMPLETED', 'ERROR', 'CANCELLED') NOT NULL DEFAULT 'QUEUE',
  image_url TEXT NULL,
  local_file_path TEXT NULL,
  mime_type VARCHAR(100) NULL,
  file_size BIGINT NULL,
  provider VARCHAR(64) NULL,
  model_admin_value VARCHAR(191) NULL,
  model_runtime_value VARCHAR(191) NULL,
  remote_url_host VARCHAR(255) NULL,
  metadata JSON NULL,
  error TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  INDEX idx_image_generations_task_id (task_id),
  INDEX idx_image_generations_user_status (user_id, status),
  INDEX idx_image_generations_owner_created (user_id, created_at),
  INDEX idx_image_generations_owner_deleted_status (user_id, deleted_at, status),
  UNIQUE INDEX uq_image_generations_owner_idempotency (user_id, idempotency_key),
  CONSTRAINT fk_image_generations_user
    FOREIGN KEY (user_id)
    REFERENCES app_users(user_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key VARCHAR(191) PRIMARY KEY,
  setting_value JSON NOT NULL,
  category VARCHAR(64) NOT NULL,
  updated_at DATETIME NOT NULL,
  INDEX idx_app_settings_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_plans (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  icon VARCHAR(64) NOT NULL DEFAULT '✨',
  tagline VARCHAR(255) NULL,
  monthly_price INT NOT NULL DEFAULT 0,
  daily_price INT NOT NULL DEFAULT 0,
  daily_message_limit INT NULL,
  daily_image_limit INT NULL,
  hourly_image_limit INT NULL,
  features JSON NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 999,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  INDEX idx_app_plans_active_sort (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_plan_daily_usage (
  user_id VARCHAR(191) NOT NULL,
  usage_date DATE NOT NULL,
  message_count INT NOT NULL DEFAULT 0,
  image_count INT NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, usage_date),
  INDEX idx_plan_daily_usage_date (usage_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_plan_hourly_usage (
  user_id VARCHAR(191) NOT NULL,
  usage_hour DATETIME NOT NULL,
  image_count INT NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, usage_hour),
  INDEX idx_plan_hourly_usage_hour (usage_hour)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_admins (
  id VARCHAR(191) PRIMARY KEY,
  username VARCHAR(191) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(64) NOT NULL DEFAULT 'superadmin',
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_app_admins_username (username),
  INDEX idx_app_admins_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_admin_audit_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  admin_username VARCHAR(191) NULL,
  action VARCHAR(100) NOT NULL,
  target VARCHAR(191) NULL,
  details JSON NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_admin_audit_created (created_at),
  INDEX idx_admin_audit_action (action),
  INDEX idx_admin_audit_username (admin_username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

