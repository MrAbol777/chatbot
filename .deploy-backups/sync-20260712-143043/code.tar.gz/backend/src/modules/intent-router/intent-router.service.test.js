const test = require('node:test');
const assert = require('node:assert/strict');

const {
  buildRouterInput,
  createIntentRouterService,
  detectDeterministicRoute
} = require('./intent-router.service');

const warriorPrompt = 'یه عکس بزن یک عکس می خواهم تولید کنم که یک جنگجوی جوان دختر با موهای بلند مشکی و لباس سیاه در آن است';

test('routes the reported warrior prompt directly to image generation', () => {
  const route = detectDeterministicRoute(buildRouterInput({ userMessage: warriorPrompt }));

  assert.equal(route?.intent, 'image_generation');
  assert.equal(route?.targetModule, 'image_generation');
  assert.equal(route?.reasonCode, 'explicit_image_generation');
});

test('routes common explicit Persian image requests without calling a model', () => {
  for (const userMessage of [
    'عکس تولید کن',
    'یه تصویر از یک قلعه بساز',
    'پوستر فضایی طراحی کن',
    '/imagine cinematic city at night'
  ]) {
    assert.equal(detectDeterministicRoute(buildRouterInput({ userMessage }))?.intent, 'image_generation');
  }
});

test('keeps a short create follow-up on the previous image-generation intent', () => {
  const route = detectDeterministicRoute(buildRouterInput({
    userMessage: 'خب بساز',
    previousUserMessage: warriorPrompt
  }));

  assert.equal(route?.intent, 'image_generation');
  assert.equal(route?.reasonCode, 'image_generation_follow_up');
});

test('does not treat an unrelated short create request as image generation', () => {
  const route = detectDeterministicRoute(buildRouterInput({
    userMessage: 'بساز',
    previousUserMessage: 'یک شعر درباره مدرسه بنویس'
  }));

  assert.equal(route, null);
});

test('preserves bounded conversational context in router input', () => {
  const input = buildRouterInput({
    userMessage: 'بساز',
    previousUserMessage: warriorPrompt,
    currentTopic: 'ساخت تصویر جنگجو',
    activeReferences: ['generated image request']
  });

  assert.equal(input.previousUserMessage, warriorPrompt);
  assert.equal(input.currentTopic, 'ساخت تصویر جنگجو');
  assert.deepEqual(input.activeReferences, ['generated image request']);
});

test('bypasses the model for an explicit image-generation request', async () => {
  let modelCalls = 0;
  const service = createIntentRouterService({
    httpClient: {
      post: async () => {
        modelCalls += 1;
        throw new Error('model must not be called');
      }
    },
    settingsRepository: { getAll: async () => ({}) },
    routerConfig: { apiKey: 'test-key' }
  });

  const result = await service.route({ userMessage: warriorPrompt });

  assert.equal(result.ok, true);
  assert.equal(result.route.intent, 'image_generation');
  assert.equal(result.metadata.source, 'deterministic_router');
  assert.equal(modelCalls, 0);
});
